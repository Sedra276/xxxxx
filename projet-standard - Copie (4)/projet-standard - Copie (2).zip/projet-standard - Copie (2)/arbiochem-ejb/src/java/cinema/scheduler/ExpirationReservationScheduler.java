/*
 * Module CINEMA - framework APJ (BICI)
 */
package cinema.scheduler;

import cinema.service.ReservationService;
import java.sql.Connection;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import utilitaire.UtilDB;

/**
 * Libere automatiquement les places des reservations expirees, toutes les 5 minutes.
 * Filet de securite : le plan de salle et la caisse appellent aussi ReservationService.expirer
 * avant affichage, donc le systeme reste correct meme si le timer est desactive.
 */
@Singleton
@Startup
public class ExpirationReservationScheduler {

    /** Utilisateur technique enregistre dans l'historique (a adapter : refuser d'un compte systeme). */
    private static final String UTILISATEUR_SYSTEME = "1";

    @Schedule(hour = "*", minute = "*/5", second = "0", persistent = false)
    public void libererReservationsExpirees() {
        Connection c = null;
        try {
            c = new UtilDB().GetConn();
            if (c == null) return;
            c.setAutoCommit(false);
            int n = ReservationService.expirer(UTILISATEUR_SYSTEME, c);
            c.commit();
            if (n > 0) System.out.println("[CINEMA] " + n + " reservation(s) expiree(s) liberee(s)");
        } catch (Exception e) {
            try { if (c != null) c.rollback(); } catch (Exception ignore) { }
            e.printStackTrace();
        } finally {
            try { if (c != null) c.close(); } catch (Exception ignore) { }
        }
    }
}
