/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.film;

import java.sql.Connection;

/**
 * Lecture seule (vue FILMGENRE_LIB).
 */
public class FilmGenreLib extends FilmGenre {

    private String idfilmlib;
    private String idgenrelib;

    public FilmGenreLib() throws Exception {
        this.setNomTable("FILMGENRE_LIB");
    }

    public String getIdfilmlib() {
        return idfilmlib;
    }

    public void setIdfilmlib(String idfilmlib) {
        this.idfilmlib = idfilmlib;
    }

    public String getIdgenrelib() {
        return idgenrelib;
    }

    public void setIdgenrelib(String idgenrelib) {
        this.idgenrelib = idgenrelib;
    }

}
