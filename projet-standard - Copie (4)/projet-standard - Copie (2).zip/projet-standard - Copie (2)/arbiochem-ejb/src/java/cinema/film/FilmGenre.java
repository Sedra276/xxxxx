/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.film;

import bean.ClassFille;
import java.sql.Connection;

/**
 * Genre associe a un film (ClassFille de Film).
 */
public class FilmGenre extends ClassFille {

    private String id;
    private String idfilm;
    private String idgenre;

    public FilmGenre() throws Exception {
        this.setNomTable("FILMGENRE");
        this.setLiaisonMere("idfilm");
        super.setNomClasseMere("cinema.film.Film");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("FGE", "GETSEQFILMGENRE");
        this.setId(makePK(c));
    }

    @Override
    public String getNomClasseMere() {
        return "cinema.film.Film";
    }

    @Override
    public String getLiaisonMere() {
        return "idfilm";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdfilm() {
        return idfilm;
    }

    public void setIdfilm(String idfilm) {
        this.idfilm = idfilm;
    }

    public String getIdgenre() {
        return idgenre;
    }

    public void setIdgenre(String idgenre) {
        this.idgenre = idgenre;
    }

}
