/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.film;

import bean.CGenUtil;
import bean.ClassMere;
import java.sql.Connection;
import java.sql.Date;

/**
 * Film (ClassMere) ; fille : FilmGenre (liaison idfilm).
 */
public class Film extends ClassMere {

    private String id;
    private String titre;
    private String description;
    private int dureeminutes;
    private Date datesortie;
    private int agemin;
    private String langueoriginale;
    private int actif;

    public Film() {
        this.setNomTable("FILM");
        this.setActif(1);
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("FLM", "GETSEQFILM");
        this.setId(makePK(c));
    }

    @Override
    public String getLiaisonFille() {
        return "idfilm";
    }

    @Override
    public String getNomClasseFille() {
        return "cinema.film.FilmGenre";
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getTitre() == null || this.getTitre().trim().isEmpty()) {
            throw new Exception("Le titre du film est obligatoire");
        }
        if (this.getDureeminutes() <= 0) {
            throw new Exception("La duree du film doit etre superieure a 0 minute");
        }
        if (this.getAgemin() < 0) {
            throw new Exception("L'age minimum ne peut pas etre negatif");
        }
    }

    @Override
    public int updateObject(String u, Connection c) throws Exception {
        this.controler(c);
        return super.updateObject(u, c);
    }

    /** Active (1) ou desactive (0) le film. Un film inactif ne peut plus etre programme. */
    public void changerActivation(int valeur, String u, Connection c) throws Exception {
        this.setActif(valeur == 1 ? 1 : 0);
        this.updateToTableWithHisto(u, c);
    }

    public static Film charger(String id, Connection c) throws Exception {
        Film[] r = (Film[]) CGenUtil.rechercher(new Film(), null, null, c,
                " and id = '" + cinema.utils.UtilCinema.id(id) + "'");
        if (r.length == 0) throw new Exception("Film introuvable");
        return r[0];
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDureeminutes() {
        return dureeminutes;
    }

    public void setDureeminutes(int dureeminutes) {
        this.dureeminutes = dureeminutes;
    }

    public Date getDatesortie() {
        return datesortie;
    }

    public void setDatesortie(Date datesortie) {
        this.datesortie = datesortie;
    }

    public int getAgemin() {
        return agemin;
    }

    public void setAgemin(int agemin) {
        this.agemin = agemin;
    }

    public String getLangueoriginale() {
        return langueoriginale;
    }

    public void setLangueoriginale(String langueoriginale) {
        this.langueoriginale = langueoriginale;
    }

    public int getActif() {
        return actif;
    }

    public void setActif(int actif) {
        this.actif = actif;
    }

}
