/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.film;

import java.sql.Connection;

/**
 * Lecture seule (vue FILM_LIB).
 */
public class FilmLib extends Film {

    private String genreslib;

    public FilmLib() {
        this.setNomTable("FILM_LIB");
    }

    public String getGenreslib() {
        return genreslib;
    }

    public void setGenreslib(String genreslib) {
        this.genreslib = genreslib;
    }

}
