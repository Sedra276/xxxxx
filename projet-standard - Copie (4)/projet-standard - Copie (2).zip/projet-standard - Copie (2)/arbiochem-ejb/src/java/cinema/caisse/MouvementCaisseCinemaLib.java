/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.caisse;

import bean.ClassMAPTable;
import java.sql.Connection;
import java.sql.Date;

/**
 * Lecture seule (vue CIN_MOUVEMENTCAISSE_LIB) : mouvements poulet rattaches a une session cinema.
 */
public class MouvementCaisseCinemaLib extends ClassMAPTable {

    private String id;
    private String idsessioncaisse;
    private String idcaisse;
    private String idcaisselib;
    private Date daty;
    private String heure;
    private String designation;
    private String idorigine;
    private double credit;
    private double debit;
    private String typemouvement;
    private int etat;

    public MouvementCaisseCinemaLib() {
        this.setNomTable("CIN_MOUVEMENTCAISSE_LIB");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdsessioncaisse() {
        return idsessioncaisse;
    }

    public void setIdsessioncaisse(String idsessioncaisse) {
        this.idsessioncaisse = idsessioncaisse;
    }

    public String getIdcaisse() {
        return idcaisse;
    }

    public void setIdcaisse(String idcaisse) {
        this.idcaisse = idcaisse;
    }

    public String getIdcaisselib() {
        return idcaisselib;
    }

    public void setIdcaisselib(String idcaisselib) {
        this.idcaisselib = idcaisselib;
    }

    public Date getDaty() {
        return daty;
    }

    public void setDaty(Date daty) {
        this.daty = daty;
    }

    public String getHeure() {
        return heure;
    }

    public void setHeure(String heure) {
        this.heure = heure;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getIdorigine() {
        return idorigine;
    }

    public void setIdorigine(String idorigine) {
        this.idorigine = idorigine;
    }

    public double getCredit() {
        return credit;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    public double getDebit() {
        return debit;
    }

    public void setDebit(double debit) {
        this.debit = debit;
    }

    public String getTypemouvement() {
        return typemouvement;
    }

    public void setTypemouvement(String typemouvement) {
        this.typemouvement = typemouvement;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

}
