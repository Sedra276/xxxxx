/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.caisse;

import java.sql.Connection;

/**
 * Lecture seule (vue SESSIONCAISSE_LIB) : solde theorique et ecart a la fermeture.
 */
public class SessionCaisseLib extends SessionCaisse {

    private String idcaisselib;
    private double totalentrees;
    private double totalsorties;
    private double montanttheorique;
    private double ecart;

    public SessionCaisseLib() {
        this.setNomTable("SESSIONCAISSE_LIB");
    }

    public String getIdcaisselib() {
        return idcaisselib;
    }

    public void setIdcaisselib(String idcaisselib) {
        this.idcaisselib = idcaisselib;
    }

    public double getTotalentrees() {
        return totalentrees;
    }

    public void setTotalentrees(double totalentrees) {
        this.totalentrees = totalentrees;
    }

    public double getTotalsorties() {
        return totalsorties;
    }

    public void setTotalsorties(double totalsorties) {
        this.totalsorties = totalsorties;
    }

    public double getMontanttheorique() {
        return montanttheorique;
    }

    public void setMontanttheorique(double montanttheorique) {
        this.montanttheorique = montanttheorique;
    }

    public double getEcart() {
        return ecart;
    }

    public void setEcart(double ecart) {
        this.ecart = ecart;
    }

}
