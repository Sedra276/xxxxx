/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.caisse;

import bean.ClassMAPTable;
import java.sql.Connection;
import java.sql.Date;

/**
 * Paiement (partiel ou total) d'une facture, sur une session de caisse ouverte.
 * idmodepaiement -> MODEPAIEMENT du poulet ; idmouvementcaisse -> mouvement poulet genere.
 */
public class PaiementFacture extends ClassMAPTable {

    private String id;
    private String idfactureclient;
    private String idsessioncaisse;
    private double montant;
    private String idmodepaiement;
    private String reference;
    private Date daty;
    private String heure;
    private String idmouvementcaisse;

    public PaiementFacture() {
        this.setNomTable("PAIEMENTFACTURE");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("PFC", "GETSEQPAIEMENTFACTURE");
        this.setId(makePK(c));
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdfactureclient() {
        return idfactureclient;
    }

    public void setIdfactureclient(String idfactureclient) {
        this.idfactureclient = idfactureclient;
    }

    public String getIdsessioncaisse() {
        return idsessioncaisse;
    }

    public void setIdsessioncaisse(String idsessioncaisse) {
        this.idsessioncaisse = idsessioncaisse;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

    public String getIdmodepaiement() {
        return idmodepaiement;
    }

    public void setIdmodepaiement(String idmodepaiement) {
        this.idmodepaiement = idmodepaiement;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Date getDaty() {
        return daty;
    }

    public void setDaty(Date daty) {
        this.daty = daty;
    }

    public String getHeure() {
        return heure;
    }

    public void setHeure(String heure) {
        this.heure = heure;
    }

    public String getIdmouvementcaisse() {
        return idmouvementcaisse;
    }

    public void setIdmouvementcaisse(String idmouvementcaisse) {
        this.idmouvementcaisse = idmouvementcaisse;
    }

}
