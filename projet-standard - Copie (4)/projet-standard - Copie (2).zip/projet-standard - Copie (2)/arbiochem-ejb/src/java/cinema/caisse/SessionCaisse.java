/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.caisse;

import bean.CGenUtil;
import bean.ClassEtat;
import cinema.utils.UtilCinema;
import java.sql.Connection;
import java.sql.Date;

/**
 * Session de caisse (ClassEtat) sur une caisse du poulet (table CAISSE).
 *   cree (1) : ouverte | cloture : fermee (montantreel compte)
 * Une seule session ouverte par caisse (index unique en base).
 */
public class SessionCaisse extends ClassEtat {

    private String id;
    private String idcaisse;
    private String idutilisateur;
    private Date dateouverture;
    private String heureouverture;
    private Date datefermeture;
    private String heurefermeture;
    private double montantinitial;
    private double montantreel;
    private String remarque;

    public SessionCaisse() {
        this.setNomTable("SESSIONCAISSE");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("SCA", "GETSEQSESSIONCAISSE");
        this.setId(makePK(c));
    }

    public boolean estOuverte() {
        return this.getEtat() == 1;
    }

    public static SessionCaisse charger(String id, Connection c) throws Exception {
        SessionCaisse[] r = (SessionCaisse[]) CGenUtil.rechercher(new SessionCaisse(), null, null, c, " and id = '" + UtilCinema.id(id) + "'");
        if (r.length == 0) throw new Exception("Session de caisse introuvable");
        return r[0];
    }

    /** Session ouverte du caissier connecte, ou null. */
    public static SessionCaisse getSessionOuverteUtilisateur(String idutilisateur, Connection c) throws Exception {
        SessionCaisse[] r = (SessionCaisse[]) CGenUtil.rechercher(new SessionCaisse(), null, null, c,
                " and etat = 1 and idutilisateur = '" + UtilCinema.id(idutilisateur) + "' order by dateouverture desc");
        return r.length == 0 ? null : r[0];
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdcaisse() {
        return idcaisse;
    }

    public void setIdcaisse(String idcaisse) {
        this.idcaisse = idcaisse;
    }

    public String getIdutilisateur() {
        return idutilisateur;
    }

    public void setIdutilisateur(String idutilisateur) {
        this.idutilisateur = idutilisateur;
    }

    public Date getDateouverture() {
        return dateouverture;
    }

    public void setDateouverture(Date dateouverture) {
        this.dateouverture = dateouverture;
    }

    public String getHeureouverture() {
        return heureouverture;
    }

    public void setHeureouverture(String heureouverture) {
        this.heureouverture = heureouverture;
    }

    public Date getDatefermeture() {
        return datefermeture;
    }

    public void setDatefermeture(Date datefermeture) {
        this.datefermeture = datefermeture;
    }

    public String getHeurefermeture() {
        return heurefermeture;
    }

    public void setHeurefermeture(String heurefermeture) {
        this.heurefermeture = heurefermeture;
    }

    public double getMontantinitial() {
        return montantinitial;
    }

    public void setMontantinitial(double montantinitial) {
        this.montantinitial = montantinitial;
    }

    public double getMontantreel() {
        return montantreel;
    }

    public void setMontantreel(double montantreel) {
        this.montantreel = montantreel;
    }

    public String getRemarque() {
        return remarque;
    }

    public void setRemarque(String remarque) {
        this.remarque = remarque;
    }

}
