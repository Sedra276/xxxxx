/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.caisse;

import caisse.MvtCaisse;
import java.sql.Connection;

/**
 * Mouvement de caisse du POULET (table MOUVEMENTCAISSE, classe caisse.MvtCaisse) + rattachement
 * a la session de caisse cinema (colonne idsessioncaisse ajoutee par le script 03).
 * credit = encaissement, debit = decaissement / remboursement.
 */
public class MvtCaisseCinema extends MvtCaisse {

    private String idsessioncaisse;

    public MvtCaisseCinema() {
    }

    public String getIdsessioncaisse() {
        return idsessioncaisse;
    }

    public void setIdsessioncaisse(String idsessioncaisse) {
        this.idsessioncaisse = idsessioncaisse;
    }

}
