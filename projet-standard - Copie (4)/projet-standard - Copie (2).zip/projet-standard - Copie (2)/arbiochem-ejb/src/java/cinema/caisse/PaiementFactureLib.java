/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.caisse;

import java.sql.Connection;

/**
 * Lecture seule (vue PAIEMENTFACTURE_LIB).
 */
public class PaiementFactureLib extends PaiementFacture {

    private String idfactureclientlib;
    private String idcaisselib;
    private String idmodepaiementlib;

    public PaiementFactureLib() {
        this.setNomTable("PAIEMENTFACTURE_LIB");
    }

    public String getIdfactureclientlib() {
        return idfactureclientlib;
    }

    public void setIdfactureclientlib(String idfactureclientlib) {
        this.idfactureclientlib = idfactureclientlib;
    }

    public String getIdcaisselib() {
        return idcaisselib;
    }

    public void setIdcaisselib(String idcaisselib) {
        this.idcaisselib = idcaisselib;
    }

    public String getIdmodepaiementlib() {
        return idmodepaiementlib;
    }

    public void setIdmodepaiementlib(String idmodepaiementlib) {
        this.idmodepaiementlib = idmodepaiementlib;
    }

}
