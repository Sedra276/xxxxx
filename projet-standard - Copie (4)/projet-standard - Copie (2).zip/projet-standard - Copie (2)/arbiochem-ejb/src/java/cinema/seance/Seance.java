/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.seance;

import bean.CGenUtil;
import bean.ClassEtat;
import cinema.film.Film;
import cinema.utils.ConstanteCinema;
import cinema.utils.UtilCinema;
import constante.ConstanteEtat;
import java.sql.Connection;
import java.sql.Date;

/**
 * Seance (ClassEtat).
 *   cree (1)     : brouillon, non visible a la caisse
 *   valide (11)  : programmee, reservable et vendable
 *   annule       : ConstanteEtat.getEtatAnnuler()
 * heurefin / datefin sont calculees (debut + duree du film), jamais saisies.
 */
public class Seance extends ClassEtat {

    private String id;
    private String idfilm;
    private String idsalle;
    private Date daty;
    private String heuredebut;
    private Date datefin;
    private String heurefin;
    private String langue;
    private String versionseance;

    public Seance() {
        this.setNomTable("SEANCE");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("SEA", "GETSEQSEANCE");
        this.setId(makePK(c));
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getIdfilm() == null || this.getIdfilm().isEmpty()) throw new Exception("Le film est obligatoire");
        if (this.getIdsalle() == null || this.getIdsalle().isEmpty()) throw new Exception("La salle est obligatoire");
        if (this.getDaty() == null) throw new Exception("La date de la seance est obligatoire");
        UtilCinema.verifierHeure(this.getHeuredebut(), "Heure de debut");
        Film film = Film.charger(this.getIdfilm(), c);
        if (film.getActif() != 1) throw new Exception("Ce film est desactive : impossible de le programmer");
        this.calculerFin(film);
        this.verifierChevauchement(c);
    }

    /** Appele par validerObject (programmation definitive) : on revalide tout. */
    @Override
    public void controlerUpdate(Connection c) throws Exception {
        super.controlerUpdate(c);
        this.controler(c);
    }

    /** updateObject n'appelle aucun crochet dans APJ : on force le controle. */
    @Override
    public int updateObject(String u, Connection c) throws Exception {
        if (this.aDesVentesOuReservations(c)) {
            Seance enBase = Seance.charger(this.getId(), c);
            if (!enBase.getIdsalle().equals(this.getIdsalle())) {
                throw new Exception("Des places sont deja vendues ou reservees : impossible de changer de salle");
            }
        }
        this.controler(c);
        return super.updateObject(u, c);
    }

    private void calculerFin(Film film) throws Exception {
        long debut = UtilCinema.instant(this.getDaty(), this.getHeuredebut());
        long fin = debut + UtilCinema.minutes(film.getDureeminutes());
        this.setDatefin(UtilCinema.dateDe(fin));
        this.setHeurefin(UtilCinema.heureDe(fin));
    }

    /**
     * Deux seances non annulees d'une meme salle ne peuvent pas se chevaucher
     * (pause de ConstanteCinema.PAUSE_ENTRE_SEANCES_MINUTES incluse).
     * Les seances de la veille et du lendemain sont aussi controlees (seances passant minuit).
     */
    private void verifierChevauchement(Connection c) throws Exception {
        long debut = this.getDebutMillis();
        long fin = this.getFinMillis() + UtilCinema.minutes(ConstanteCinema.PAUSE_ENTRE_SEANCES_MINUTES);
        String w = " and idsalle = '" + UtilCinema.id(this.getIdsalle()) + "'"
                + " and daty between " + UtilCinema.dateSql(this.getDaty()) + " - 1 and " + UtilCinema.dateSql(this.getDaty()) + " + 1"
                + " and etat <> " + ConstanteEtat.getEtatAnnuler();
        if (this.getId() != null && !this.getId().isEmpty()) w += " and id <> '" + UtilCinema.id(this.getId()) + "'";
        Seance[] autres = (Seance[]) CGenUtil.rechercher(new Seance(), null, null, c, w);
        for (int i = 0; i < autres.length; i++) {
            long d2 = autres[i].getDebutMillis();
            long f2 = autres[i].getFinMillis() + UtilCinema.minutes(ConstanteCinema.PAUSE_ENTRE_SEANCES_MINUTES);
            if (debut < f2 && d2 < fin) {
                throw new Exception("Chevauchement avec la seance " + autres[i].getId() + " ("
                        + UtilCinema.formatDate(autres[i].getDaty()) + " " + autres[i].getHeuredebut() + "-" + autres[i].getHeurefin()
                        + ") dans la meme salle");
            }
        }
    }

    public long getDebutMillis() throws Exception {
        return UtilCinema.instant(this.getDaty(), this.getHeuredebut());
    }

    public long getFinMillis() throws Exception {
        if (this.getDatefin() == null || this.getHeurefin() == null) return this.getDebutMillis();
        return UtilCinema.instant(this.getDatefin(), this.getHeurefin());
    }

    /** Reservable / vendable : programmee (validee), non annulee, pas encore terminee. */
    public void verifierVendable() throws Exception {
        if (this.getEtat() == ConstanteEtat.getEtatAnnuler()) throw new Exception("Cette seance est annulee");
        if (this.getEtat() < ConstanteEtat.getEtatValider()) throw new Exception("Cette seance n'est pas encore programmee (non validee)");
        long limite = this.getDebutMillis() + UtilCinema.minutes(ConstanteCinema.VENTE_APRES_DEBUT_MINUTES);
        if (System.currentTimeMillis() > limite) throw new Exception("La vente est close pour cette seance");
    }

    public boolean aDesVentesOuReservations(Connection c) throws Exception {
        if (this.getId() == null || this.getId().isEmpty()) return false;
        Object[] r = CGenUtil.rechercher(new PlanSalle(), null, null, c,
                " and idseance = '" + UtilCinema.id(this.getId()) + "' and etatplace <> '" + ConstanteCinema.PL_LIBRE + "'");
        return r.length > 0;
    }

    public static Seance charger(String id, Connection c) throws Exception {
        Seance[] r = (Seance[]) CGenUtil.rechercher(new Seance(), null, null, c, " and id = '" + UtilCinema.id(id) + "'");
        if (r.length == 0) throw new Exception("Seance introuvable");
        return r[0];
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdfilm() {
        return idfilm;
    }

    public void setIdfilm(String idfilm) {
        this.idfilm = idfilm;
    }

    public String getIdsalle() {
        return idsalle;
    }

    public void setIdsalle(String idsalle) {
        this.idsalle = idsalle;
    }

    public Date getDaty() {
        return daty;
    }

    public void setDaty(Date daty) {
        this.daty = daty;
    }

    public String getHeuredebut() {
        return heuredebut;
    }

    public void setHeuredebut(String heuredebut) {
        this.heuredebut = heuredebut;
    }

    public Date getDatefin() {
        return datefin;
    }

    public void setDatefin(Date datefin) {
        this.datefin = datefin;
    }

    public String getHeurefin() {
        return heurefin;
    }

    public void setHeurefin(String heurefin) {
        this.heurefin = heurefin;
    }

    public String getLangue() {
        return langue;
    }

    public void setLangue(String langue) {
        this.langue = langue;
    }

    public String getVersionseance() {
        return versionseance;
    }

    public void setVersionseance(String versionseance) {
        this.versionseance = versionseance;
    }

}
