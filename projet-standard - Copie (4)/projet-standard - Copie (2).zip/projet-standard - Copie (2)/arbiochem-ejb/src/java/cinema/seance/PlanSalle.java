/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.seance;

import bean.CGenUtil;
import bean.ClassMAPTable;
import cinema.utils.UtilCinema;
import java.sql.Connection;

/**
 * Plan de salle d'une seance (vue PLANSALLE_LIB) : etat LIBRE / RESERVEE / VENDUE de chaque place.
 * Lecture seule.
 */
public class PlanSalle extends ClassMAPTable {

    private String id;
    private String idseance;
    private int etatseance;
    private String idplace;
    private String idsalle;
    private String rangee;
    private int numero;
    private String idtypeplace;
    private String idtypeplacelib;
    private String etatplace;
    private String idticket;
    private String idreservation;

    public PlanSalle() {
        this.setNomTable("PLANSALLE_LIB");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    /** Plan complet d'une seance, trie par rangee puis numero. */
    public static PlanSalle[] charger(String idseance, Connection c) throws Exception {
        return (PlanSalle[]) CGenUtil.rechercher(new PlanSalle(), null, null, c,
                " and idseance = '" + UtilCinema.id(idseance) + "' order by rangee, numero");
    }

    /** Etat des places demandees ; erreur si une place n'appartient pas a la salle de la seance. */
    public static PlanSalle[] chargerPlaces(String idseance, String[] idplaces, Connection c) throws Exception {
        PlanSalle[] r = (PlanSalle[]) CGenUtil.rechercher(new PlanSalle(), null, null, c,
                " and idseance = '" + UtilCinema.id(idseance) + "' and idplace in (" + UtilCinema.listeIn(idplaces) + ")");
        if (r.length != idplaces.length) {
            throw new Exception("Une ou plusieurs places ne correspondent pas a la salle de la seance (ou sont en double)");
        }
        return r;
    }

    public String getLibellePlace() {
        return (rangee == null ? "" : rangee) + numero;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdseance() {
        return idseance;
    }

    public void setIdseance(String idseance) {
        this.idseance = idseance;
    }

    public int getEtatseance() {
        return etatseance;
    }

    public void setEtatseance(int etatseance) {
        this.etatseance = etatseance;
    }

    public String getIdplace() {
        return idplace;
    }

    public void setIdplace(String idplace) {
        this.idplace = idplace;
    }

    public String getIdsalle() {
        return idsalle;
    }

    public void setIdsalle(String idsalle) {
        this.idsalle = idsalle;
    }

    public String getRangee() {
        return rangee;
    }

    public void setRangee(String rangee) {
        this.rangee = rangee;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getIdtypeplace() {
        return idtypeplace;
    }

    public void setIdtypeplace(String idtypeplace) {
        this.idtypeplace = idtypeplace;
    }

    public String getIdtypeplacelib() {
        return idtypeplacelib;
    }

    public void setIdtypeplacelib(String idtypeplacelib) {
        this.idtypeplacelib = idtypeplacelib;
    }

    public String getEtatplace() {
        return etatplace;
    }

    public void setEtatplace(String etatplace) {
        this.etatplace = etatplace;
    }

    public String getIdticket() {
        return idticket;
    }

    public void setIdticket(String idticket) {
        this.idticket = idticket;
    }

    public String getIdreservation() {
        return idreservation;
    }

    public void setIdreservation(String idreservation) {
        this.idreservation = idreservation;
    }

}
