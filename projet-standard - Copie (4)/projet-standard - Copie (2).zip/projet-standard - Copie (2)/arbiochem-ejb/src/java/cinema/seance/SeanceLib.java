/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.seance;

import java.sql.Connection;

/**
 * Lecture seule (vue SEANCE_LIB).
 */
public class SeanceLib extends Seance {

    private String idfilmlib;
    private int dureeminutes;
    private String idsallelib;
    private int capacite;
    private String libelle;

    public SeanceLib() {
        this.setNomTable("SEANCE_LIB");
    }

    public String getIdfilmlib() {
        return idfilmlib;
    }

    public void setIdfilmlib(String idfilmlib) {
        this.idfilmlib = idfilmlib;
    }

    public int getDureeminutes() {
        return dureeminutes;
    }

    public void setDureeminutes(int dureeminutes) {
        this.dureeminutes = dureeminutes;
    }

    public String getIdsallelib() {
        return idsallelib;
    }

    public void setIdsallelib(String idsallelib) {
        this.idsallelib = idsallelib;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

}
