/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.referentiel;

import bean.TypeObjet;
import java.sql.Connection;

/**
 * Categorie de client (Adulte, Enfant, Etudiant...). Referentiel bean.TypeObjet (id / val / desce).
 */
public class CategorieClient extends TypeObjet {


    public CategorieClient() {
        this.setNomTable("TYPECATEGORIECLIENT");
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("TCC", "GETSEQTYPECATEGORIECLIENT");
        this.setId(makePK(c));
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getVal() == null || this.getVal().trim().isEmpty()) {
            throw new Exception("Le libelle est obligatoire");
        }
    }

}
