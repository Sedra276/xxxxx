/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.referentiel;

import bean.TypeObjet;
import java.sql.Connection;

/**
 * Genre de film. Referentiel bean.TypeObjet (id / val / desce).
 */
public class Genre extends TypeObjet {


    public Genre() {
        this.setNomTable("TYPEGENRE");
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("TGE", "GETSEQTYPEGENRE");
        this.setId(makePK(c));
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getVal() == null || this.getVal().trim().isEmpty()) {
            throw new Exception("Le libelle est obligatoire");
        }
    }

}
