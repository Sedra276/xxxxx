/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.referentiel;

import bean.TypeObjet;
import java.sql.Connection;

/**
 * Type de place (Standard, VIP, Premium...). Referentiel bean.TypeObjet (id / val / desce).
 */
public class TypePlace extends TypeObjet {


    public TypePlace() {
        this.setNomTable("TYPEPLACE");
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("TPL", "GETSEQTYPEPLACE");
        this.setId(makePK(c));
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getVal() == null || this.getVal().trim().isEmpty()) {
            throw new Exception("Le libelle est obligatoire");
        }
    }

}
