/*
 * Module CINEMA - framework APJ (BICI)
 */
package cinema.utils;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.UUID;

/**
 * Outils du module cinema : securite SQL, dates/heures, codes uniques.
 *
 * IMPORTANT : le framework APJ concatene le SQL (pas de PreparedStatement).
 * Toute valeur venant de l'utilisateur et injectee dans un apresWhere doit
 * passer par id() ou esc().
 */
public class UtilCinema {

    private static final String REGEX_ID = "^[A-Za-z0-9_\\-]{1,100}$";
    private static final String REGEX_HEURE = "^([01][0-9]|2[0-3]):[0-5][0-9]$";

    /** Echappe une chaine pour un litteral SQL entre quotes. */
    public static String esc(String s) {
        if (s == null) return "";
        return s.replace("'", "''");
    }

    /** Verifie qu'un identifiant ne contient que des caracteres surs, puis le renvoie. */
    public static String id(String s) throws Exception {
        if (s == null || !s.matches(REGEX_ID)) {
            throw new Exception("Identifiant invalide");
        }
        return s;
    }

    public static boolean estVide(String s) {
        return s == null || s.trim().isEmpty();
    }

    /** Liste SQL d'identifiants : 'A','B','C' (chaque id est verifie). */
    public static String listeIn(String[] ids) throws Exception {
        if (ids == null || ids.length == 0) throw new Exception("Aucun element selectionne");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ids.length; i++) {
            if (i > 0) sb.append(",");
            sb.append("'").append(id(ids[i])).append("'");
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- dates / heures

    public static Date aujourdhui() {
        return new Date(System.currentTimeMillis());
    }

    public static String heureCourante() {
        return new SimpleDateFormat("HH:mm").format(new java.util.Date());
    }

    /** Date au format SQL Oracle : TO_DATE('dd/MM/yyyy','DD/MM/YYYY'). */
    public static String dateSql(Date d) {
        return "TO_DATE('" + new SimpleDateFormat("dd/MM/yyyy").format(d) + "','DD/MM/YYYY')";
    }

    public static String formatDate(Date d) {
        if (d == null) return "";
        return new SimpleDateFormat("dd/MM/yyyy").format(d);
    }

    public static void verifierHeure(String hhmm, String libelle) throws Exception {
        if (hhmm == null || !hhmm.matches(REGEX_HEURE)) {
            throw new Exception(libelle + " invalide : format attendu HH:MM (ex : 14:30)");
        }
    }

    /** Instant (millisecondes) correspondant a une date + une heure HH:MM. */
    public static long instant(Date d, String hhmm) throws Exception {
        if (d == null) throw new Exception("Date manquante");
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        int h = 0, m = 0;
        if (!estVide(hhmm)) {
            verifierHeure(hhmm, "Heure");
            h = Integer.parseInt(hhmm.substring(0, 2));
            m = Integer.parseInt(hhmm.substring(3, 5));
        }
        cal.set(Calendar.HOUR_OF_DAY, h);
        cal.set(Calendar.MINUTE, m);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    public static Date dateDe(long instant) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(instant);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return new Date(cal.getTimeInMillis());
    }

    public static String heureDe(long instant) {
        return new SimpleDateFormat("HH:mm").format(new java.util.Date(instant));
    }

    public static long minutes(int n) {
        return n * 60L * 1000L;
    }

    // ---------------------------------------------------------------- divers

    /** Code unique imprime sur le ticket (controle a l'entree). */
    public static String codeTicket() {
        return "TK-" + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();
    }

    public static String tronquer(String s, int max) {
        if (s == null) return null;
        return s.length() <= max ? s : s.substring(0, max);
    }

    public static double arrondi(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
