/*
 * Module CINEMA - framework APJ (BICI)
 */
package cinema.utils;

import affichage.Champ;
import affichage.Formulaire;
import affichage.PageConsulte;

/**
 * Raccourcis d'ecran : libelles et masquage de champs, sans NullPointerException
 * quand un champ n'existe pas (regle de l'intersection : un champ absent est silencieux).
 */
public class UtilPage {

    public static void libelle(Formulaire f, String nom, String libelle) {
        Champ ch = f.getChamp(nom);
        if (ch != null) ch.setLibelle(libelle);
    }

    /** Applique des libelles par paires : {"nom","Libelle","prenom","Pr&eacute;nom",...}. */
    public static void libelles(Formulaire f, String[] paires) {
        for (int i = 0; i + 1 < paires.length; i += 2) libelle(f, paires[i], paires[i + 1]);
    }

    public static void cacher(Formulaire f, String[] noms) {
        for (int i = 0; i < noms.length; i++) {
            Champ ch = f.getChamp(noms[i]);
            if (ch != null) ch.setVisible(false);
        }
    }

    public static void defaut(Formulaire f, String nom, String valeur) {
        Champ ch = f.getChamp(nom);
        if (ch != null && valeur != null) ch.setDefaut(valeur);
    }

    public static void lectureSeule(Formulaire f, String nom) {
        Champ ch = f.getChamp(nom);
        if (ch != null) ch.setAutre("readonly");
    }

    public static void libelles(PageConsulte pc, String[] paires) {
        for (int i = 0; i + 1 < paires.length; i += 2) {
            Champ ch = pc.getChampByName(paires[i]);
            if (ch != null) ch.setLibelle(paires[i + 1]);
        }
    }

    public static void cacher(PageConsulte pc, String[] noms) {
        for (int i = 0; i < noms.length; i++) {
            Champ ch = pc.getChampByName(noms[i]);
            if (ch != null) ch.setVisible(false);
        }
    }

    /** Libelle lisible d'un etat ClassEtat (1 cree, 11 valide...). */
    public static String libelleEtat(int etat) {
        if (etat == constante.ConstanteEtat.getEtatAnnuler()) return "Annul&eacute;";
        if (etat == constante.ConstanteEtat.getEtatCloture()) return "Cl&ocirc;tur&eacute;";
        if (etat >= constante.ConstanteEtat.getEtatValider()) return "Valid&eacute;";
        if (etat == constante.ConstanteEtat.getEtatCreer()) return "Cr&eacute;&eacute;";
        return String.valueOf(etat);
    }

    /** Badge HTML d'etat (bootstrap). */
    public static String badgeEtat(int etat) {
        String css = "label-default";
        if (etat == constante.ConstanteEtat.getEtatAnnuler()) css = "label-danger";
        else if (etat == constante.ConstanteEtat.getEtatCloture()) css = "label-info";
        else if (etat >= constante.ConstanteEtat.getEtatValider()) css = "label-success";
        else if (etat == constante.ConstanteEtat.getEtatCreer()) css = "label-warning";
        return "<span class=\"label " + css + "\">" + libelleEtat(etat) + "</span>";
    }

    public static String montant(double v) {
        return String.format(java.util.Locale.FRANCE, "%,.2f", v) + " Ar";
    }

    /** Echappement HTML minimal pour afficher une valeur saisie par un utilisateur. */
    public static String html(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;");
    }
}
