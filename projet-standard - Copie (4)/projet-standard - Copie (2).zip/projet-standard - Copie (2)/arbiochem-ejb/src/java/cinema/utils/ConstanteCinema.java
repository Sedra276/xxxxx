/*
 * Module CINEMA - framework APJ (BICI)
 */
package cinema.utils;

/**
 * Constantes metier du module cinema.
 * Les etats de cycle de vie (cree, valide, cloture, annule) ne sont PAS ici :
 * toujours utiliser constante.ConstanteEtat.
 */
public class ConstanteCinema {

    // DETAILSRESERVATION.etatoccupation
    public static final String OCC_RESERVEE = "RESERVEE";
    public static final String OCC_CONVERTIE = "CONVERTIE";
    public static final String OCC_LIBEREE = "LIBEREE";

    // TICKET.statut
    public static final String TK_VALIDE = "VALIDE";
    public static final String TK_ANNULE = "ANNULE";
    public static final String TK_REMBOURSE = "REMBOURSE";
    public static final String TK_UTILISE = "UTILISE";

    // PLANSALLE_LIB.etatplace
    public static final String PL_LIBRE = "LIBRE";
    public static final String PL_RESERVEE = "RESERVEE";
    public static final String PL_VENDUE = "VENDUE";

    // PUBDIFFUSION.statut
    public static final String PUB_PREVUE = "PREVUE";
    public static final String PUB_DIFFUSEE = "DIFFUSEE";
    public static final String PUB_ANNULEE = "ANNULEE";

    // Regles de gestion (a ajuster selon le cinema)
    /** Pause minimale entre deux seances d'une meme salle (nettoyage, entree). */
    public static final int PAUSE_ENTRE_SEANCES_MINUTES = 15;
    /** Une reservation en attente expire au plus tard ce delai avant le debut de la seance. */
    public static final int EXPIRATION_AVANT_SEANCE_MINUTES = 30;
    /** Duree de validite par defaut d'une reservation en attente. */
    public static final int VALIDITE_RESERVATION_HEURES = 24;
    /** La vente reste possible jusqu'a ce delai apres le debut de la seance. */
    public static final int VENTE_APRES_DEBUT_MINUTES = 15;
    /** Remboursement autorise jusqu'a ce delai avant le debut de la seance. */
    public static final int REMBOURSEMENT_AVANT_SEANCE_MINUTES = 60;

    // Facturation
    public static final double TVA_BILLET = 0;
    public static final int LONGUEUR_DESIGNATION_LIGNE = 150;

    // Tables / vues (centralisees pour eviter les fautes de frappe)
    public static final String VUE_PLANSALLE = "PLANSALLE_LIB";
    public static final String VUE_FACTURE = "FACTURECLIENT_LIB";
    public static final String VUE_SEANCE = "SEANCE_LIB";
}
