/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.vente;

import bean.CGenUtil;
import bean.ClassMAPTable;
import cinema.utils.UtilCinema;
import java.sql.Connection;
import java.sql.Date;

/**
 * Ticket : une place precise pour une seance precise. prix = prix historique fige a la vente.
 * statut : VALIDE / ANNULE / REMBOURSE / UTILISE.
 */
public class Ticket extends ClassMAPTable {

    private String id;
    private String idreservation;
    private String idfactureclientdetails;
    private String idseance;
    private String idplace;
    private String idcategorieclient;
    private double prix;
    private String codeunique;
    private String statut;
    private Date daty;
    private String heure;

    public Ticket() {
        this.setNomTable("TICKET");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("TKT", "GETSEQTICKET");
        this.setId(makePK(c));
    }

    public static Ticket charger(String id, Connection c) throws Exception {
        Ticket[] r = (Ticket[]) CGenUtil.rechercher(new Ticket(), null, null, c, " and id = '" + UtilCinema.id(id) + "'");
        if (r.length == 0) throw new Exception("Ticket introuvable");
        return r[0];
    }

    public static Ticket chargerParCode(String code, Connection c) throws Exception {
        Ticket[] r = (Ticket[]) CGenUtil.rechercher(new Ticket(), null, null, c, " and codeunique = '" + UtilCinema.id(code) + "'");
        if (r.length == 0) throw new Exception("Ticket inconnu");
        return r[0];
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdreservation() {
        return idreservation;
    }

    public void setIdreservation(String idreservation) {
        this.idreservation = idreservation;
    }

    public String getIdfactureclientdetails() {
        return idfactureclientdetails;
    }

    public void setIdfactureclientdetails(String idfactureclientdetails) {
        this.idfactureclientdetails = idfactureclientdetails;
    }

    public String getIdseance() {
        return idseance;
    }

    public void setIdseance(String idseance) {
        this.idseance = idseance;
    }

    public String getIdplace() {
        return idplace;
    }

    public void setIdplace(String idplace) {
        this.idplace = idplace;
    }

    public String getIdcategorieclient() {
        return idcategorieclient;
    }

    public void setIdcategorieclient(String idcategorieclient) {
        this.idcategorieclient = idcategorieclient;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public String getCodeunique() {
        return codeunique;
    }

    public void setCodeunique(String codeunique) {
        this.codeunique = codeunique;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Date getDaty() {
        return daty;
    }

    public void setDaty(Date daty) {
        this.daty = daty;
    }

    public String getHeure() {
        return heure;
    }

    public void setHeure(String heure) {
        this.heure = heure;
    }

}
