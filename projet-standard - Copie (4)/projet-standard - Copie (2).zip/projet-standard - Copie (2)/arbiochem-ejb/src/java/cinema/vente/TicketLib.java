/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.vente;

import java.sql.Connection;
import java.sql.Date;

/**
 * Lecture seule (vue TICKET_LIB) : sert aussi a l'impression des tickets.
 */
public class TicketLib extends Ticket {

    private String idplacelib;
    private String typeplacelib;
    private String idcategorieclientlib;
    private String film;
    private Date datyseance;
    private String heureseance;
    private String salle;
    private String idfactureclient;

    public TicketLib() {
        this.setNomTable("TICKET_LIB");
    }

    public String getIdplacelib() {
        return idplacelib;
    }

    public void setIdplacelib(String idplacelib) {
        this.idplacelib = idplacelib;
    }

    public String getTypeplacelib() {
        return typeplacelib;
    }

    public void setTypeplacelib(String typeplacelib) {
        this.typeplacelib = typeplacelib;
    }

    public String getIdcategorieclientlib() {
        return idcategorieclientlib;
    }

    public void setIdcategorieclientlib(String idcategorieclientlib) {
        this.idcategorieclientlib = idcategorieclientlib;
    }

    public String getFilm() {
        return film;
    }

    public void setFilm(String film) {
        this.film = film;
    }

    public Date getDatyseance() {
        return datyseance;
    }

    public void setDatyseance(Date datyseance) {
        this.datyseance = datyseance;
    }

    public String getHeureseance() {
        return heureseance;
    }

    public void setHeureseance(String heureseance) {
        this.heureseance = heureseance;
    }

    public String getSalle() {
        return salle;
    }

    public void setSalle(String salle) {
        this.salle = salle;
    }

    public String getIdfactureclient() {
        return idfactureclient;
    }

    public void setIdfactureclient(String idfactureclient) {
        this.idfactureclient = idfactureclient;
    }

}
