/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.dashboard;

import bean.ClassMAPTable;
import java.sql.Connection;
import java.sql.Date;

/**
 * Taux de remplissage par seance (vue V_CIN_REMPLISSAGE).
 */
public class Remplissage extends ClassMAPTable {

    private String id;
    private Date daty;
    private String idfilm;
    private String film;
    private String idsalle;
    private String salle;
    private String seance;
    private int nbplaces;
    private int nbvendues;
    private int nbreservees;
    private double tauxremplissage;

    public Remplissage() {
        this.setNomTable("V_CIN_REMPLISSAGE");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getDaty() {
        return daty;
    }

    public void setDaty(Date daty) {
        this.daty = daty;
    }

    public String getIdfilm() {
        return idfilm;
    }

    public void setIdfilm(String idfilm) {
        this.idfilm = idfilm;
    }

    public String getFilm() {
        return film;
    }

    public void setFilm(String film) {
        this.film = film;
    }

    public String getIdsalle() {
        return idsalle;
    }

    public void setIdsalle(String idsalle) {
        this.idsalle = idsalle;
    }

    public String getSalle() {
        return salle;
    }

    public void setSalle(String salle) {
        this.salle = salle;
    }

    public String getSeance() {
        return seance;
    }

    public void setSeance(String seance) {
        this.seance = seance;
    }

    public int getNbplaces() {
        return nbplaces;
    }

    public void setNbplaces(int nbplaces) {
        this.nbplaces = nbplaces;
    }

    public int getNbvendues() {
        return nbvendues;
    }

    public void setNbvendues(int nbvendues) {
        this.nbvendues = nbvendues;
    }

    public int getNbreservees() {
        return nbreservees;
    }

    public void setNbreservees(int nbreservees) {
        this.nbreservees = nbreservees;
    }

    public double getTauxremplissage() {
        return tauxremplissage;
    }

    public void setTauxremplissage(double tauxremplissage) {
        this.tauxremplissage = tauxremplissage;
    }

}
