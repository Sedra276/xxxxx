/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.dashboard;

import bean.ClassMAPTable;
import java.sql.Connection;

/**
 * Indicateurs globaux (vue V_CIN_KPI, une ligne).
 */
public class Kpi extends ClassMAPTable {

    private String id;
    private int nbfilms;
    private int nbsalles;
    private int nbseancesavenir;
    private int nbtickets;
    private int nbreservationsactives;
    private double cajour;

    public Kpi() {
        this.setNomTable("V_CIN_KPI");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getNbfilms() {
        return nbfilms;
    }

    public void setNbfilms(int nbfilms) {
        this.nbfilms = nbfilms;
    }

    public int getNbsalles() {
        return nbsalles;
    }

    public void setNbsalles(int nbsalles) {
        this.nbsalles = nbsalles;
    }

    public int getNbseancesavenir() {
        return nbseancesavenir;
    }

    public void setNbseancesavenir(int nbseancesavenir) {
        this.nbseancesavenir = nbseancesavenir;
    }

    public int getNbtickets() {
        return nbtickets;
    }

    public void setNbtickets(int nbtickets) {
        this.nbtickets = nbtickets;
    }

    public int getNbreservationsactives() {
        return nbreservationsactives;
    }

    public void setNbreservationsactives(int nbreservationsactives) {
        this.nbreservationsactives = nbreservationsactives;
    }

    public double getCajour() {
        return cajour;
    }

    public void setCajour(double cajour) {
        this.cajour = cajour;
    }

}
