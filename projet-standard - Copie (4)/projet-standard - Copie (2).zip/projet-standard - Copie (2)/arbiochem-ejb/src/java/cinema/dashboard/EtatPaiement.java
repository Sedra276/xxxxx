/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.dashboard;

import bean.ClassMAPTable;
import java.sql.Connection;

/**
 * Etat des paiements des factures (vue V_CIN_ETAT_PAIEMENT).
 */
public class EtatPaiement extends ClassMAPTable {

    private String id;
    private String statutpaiement;
    private int nbfactures;
    private double montantttc;
    private double montantpaye;
    private double resteapayer;

    public EtatPaiement() {
        this.setNomTable("V_CIN_ETAT_PAIEMENT");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatutpaiement() {
        return statutpaiement;
    }

    public void setStatutpaiement(String statutpaiement) {
        this.statutpaiement = statutpaiement;
    }

    public int getNbfactures() {
        return nbfactures;
    }

    public void setNbfactures(int nbfactures) {
        this.nbfactures = nbfactures;
    }

    public double getMontantttc() {
        return montantttc;
    }

    public void setMontantttc(double montantttc) {
        this.montantttc = montantttc;
    }

    public double getMontantpaye() {
        return montantpaye;
    }

    public void setMontantpaye(double montantpaye) {
        this.montantpaye = montantpaye;
    }

    public double getResteapayer() {
        return resteapayer;
    }

    public void setResteapayer(double resteapayer) {
        this.resteapayer = resteapayer;
    }

}
