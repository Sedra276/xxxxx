/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.dashboard;

import bean.ClassMAPTable;
import java.sql.Connection;
import java.sql.Date;

/**
 * Recettes publicitaires (vue V_CIN_VENTE_PUB).
 */
public class VentePub extends ClassMAPTable {

    private String id;
    private Date daty;
    private String mois;
    private String idclient;
    private String annonceur;
    private String idcampagne;
    private String campagne;
    private String idvideo;
    private String video;
    private int nbdiffusion;
    private double montant;

    public VentePub() {
        this.setNomTable("V_CIN_VENTE_PUB");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getDaty() {
        return daty;
    }

    public void setDaty(Date daty) {
        this.daty = daty;
    }

    public String getMois() {
        return mois;
    }

    public void setMois(String mois) {
        this.mois = mois;
    }

    public String getIdclient() {
        return idclient;
    }

    public void setIdclient(String idclient) {
        this.idclient = idclient;
    }

    public String getAnnonceur() {
        return annonceur;
    }

    public void setAnnonceur(String annonceur) {
        this.annonceur = annonceur;
    }

    public String getIdcampagne() {
        return idcampagne;
    }

    public void setIdcampagne(String idcampagne) {
        this.idcampagne = idcampagne;
    }

    public String getCampagne() {
        return campagne;
    }

    public void setCampagne(String campagne) {
        this.campagne = campagne;
    }

    public String getIdvideo() {
        return idvideo;
    }

    public void setIdvideo(String idvideo) {
        this.idvideo = idvideo;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public int getNbdiffusion() {
        return nbdiffusion;
    }

    public void setNbdiffusion(int nbdiffusion) {
        this.nbdiffusion = nbdiffusion;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

}
