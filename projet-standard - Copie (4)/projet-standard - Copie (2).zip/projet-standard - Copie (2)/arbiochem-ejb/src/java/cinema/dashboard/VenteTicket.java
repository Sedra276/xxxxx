/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.dashboard;

import bean.ClassMAPTable;
import java.sql.Connection;
import java.sql.Date;

/**
 * Une ligne par ticket vendu (vue V_CIN_VENTE_TICKET) : CA par jour / semaine / mois / film / seance / type de place.
 */
public class VenteTicket extends ClassMAPTable {

    private String id;
    private Date daty;
    private String semaine;
    private String mois;
    private String idfilm;
    private String film;
    private String idseance;
    private String seance;
    private String idsalle;
    private String salle;
    private String idtypeplace;
    private String typeplace;
    private String idcategorieclient;
    private String categorieclient;
    private int nbticket;
    private double montant;

    public VenteTicket() {
        this.setNomTable("V_CIN_VENTE_TICKET");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getDaty() {
        return daty;
    }

    public void setDaty(Date daty) {
        this.daty = daty;
    }

    public String getSemaine() {
        return semaine;
    }

    public void setSemaine(String semaine) {
        this.semaine = semaine;
    }

    public String getMois() {
        return mois;
    }

    public void setMois(String mois) {
        this.mois = mois;
    }

    public String getIdfilm() {
        return idfilm;
    }

    public void setIdfilm(String idfilm) {
        this.idfilm = idfilm;
    }

    public String getFilm() {
        return film;
    }

    public void setFilm(String film) {
        this.film = film;
    }

    public String getIdseance() {
        return idseance;
    }

    public void setIdseance(String idseance) {
        this.idseance = idseance;
    }

    public String getSeance() {
        return seance;
    }

    public void setSeance(String seance) {
        this.seance = seance;
    }

    public String getIdsalle() {
        return idsalle;
    }

    public void setIdsalle(String idsalle) {
        this.idsalle = idsalle;
    }

    public String getSalle() {
        return salle;
    }

    public void setSalle(String salle) {
        this.salle = salle;
    }

    public String getIdtypeplace() {
        return idtypeplace;
    }

    public void setIdtypeplace(String idtypeplace) {
        this.idtypeplace = idtypeplace;
    }

    public String getTypeplace() {
        return typeplace;
    }

    public void setTypeplace(String typeplace) {
        this.typeplace = typeplace;
    }

    public String getIdcategorieclient() {
        return idcategorieclient;
    }

    public void setIdcategorieclient(String idcategorieclient) {
        this.idcategorieclient = idcategorieclient;
    }

    public String getCategorieclient() {
        return categorieclient;
    }

    public void setCategorieclient(String categorieclient) {
        this.categorieclient = categorieclient;
    }

    public int getNbticket() {
        return nbticket;
    }

    public void setNbticket(int nbticket) {
        this.nbticket = nbticket;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

}
