/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.facture;

import bean.CGenUtil;
import bean.ClassMere;
import cinema.utils.UtilCinema;
import java.sql.Connection;
import java.sql.Date;

/**
 * Facture client (table FACTURECLIENT existante, structure conservee a l'identique).
 *   cree (1) | validee (11) | cloture : soldee | annule
 * Fille : FactureClientDetails (liaison idfactureclient).
 */
public class FactureClient extends ClassMere {

    private String id;
    private String idclient;
    private Date daty;
    private String designation;
    private Date dateecheancepaiement;
    private double tva;
    private String idreservation;

    public FactureClient() {
        this.setNomTable("FACTURECLIENT");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("FAC", "GET_SEQ_FACTURECLIENT");
        this.setId(makePK(c));
    }

    @Override
    public String getLiaisonFille() {
        return "idfactureclient";
    }

    @Override
    public String getNomClasseFille() {
        return "cinema.facture.FactureClientDetails";
    }

    public FactureClientDetails[] getLignes(Connection c) throws Exception {
        return (FactureClientDetails[]) CGenUtil.rechercher(new FactureClientDetails(), null, null, c,
                " and idfactureclient = '" + UtilCinema.id(this.getId()) + "' order by id");
    }

    public static FactureClient charger(String id, Connection c) throws Exception {
        FactureClient[] r = (FactureClient[]) CGenUtil.rechercher(new FactureClient(), null, null, c, " and id = '" + UtilCinema.id(id) + "'");
        if (r.length == 0) throw new Exception("Facture introuvable");
        return r[0];
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdclient() {
        return idclient;
    }

    public void setIdclient(String idclient) {
        this.idclient = idclient;
    }

    public Date getDaty() {
        return daty;
    }

    public void setDaty(Date daty) {
        this.daty = daty;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Date getDateecheancepaiement() {
        return dateecheancepaiement;
    }

    public void setDateecheancepaiement(Date dateecheancepaiement) {
        this.dateecheancepaiement = dateecheancepaiement;
    }

    public double getTva() {
        return tva;
    }

    public void setTva(double tva) {
        this.tva = tva;
    }

    public String getIdreservation() {
        return idreservation;
    }

    public void setIdreservation(String idreservation) {
        this.idreservation = idreservation;
    }

}
