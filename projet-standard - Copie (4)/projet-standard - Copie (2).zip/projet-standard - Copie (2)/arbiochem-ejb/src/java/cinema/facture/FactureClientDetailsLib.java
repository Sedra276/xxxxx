/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.facture;

import java.sql.Connection;

/**
 * Lecture seule (vue FACTURECLIENTDETAILS_LIB).
 */
public class FactureClientDetailsLib extends FactureClientDetails {

    private double montantht;
    private double montantttc;

    public FactureClientDetailsLib() throws Exception {
        this.setNomTable("FACTURECLIENTDETAILS_LIB");
    }

    public double getMontantht() {
        return montantht;
    }

    public void setMontantht(double montantht) {
        this.montantht = montantht;
    }

    public double getMontantttc() {
        return montantttc;
    }

    public void setMontantttc(double montantttc) {
        this.montantttc = montantttc;
    }

}
