/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.facture;

import bean.ClassFille;
import cinema.utils.ConstanteCinema;
import cinema.utils.UtilCinema;
import java.sql.Connection;

/**
 * Ligne de facture (table FACTURECLIENTDETAILS existante).
 * idacte = id de la seance (billet) ou de la diffusion publicitaire. idproduit reste NULL (FK vers PRODUIT).
 */
public class FactureClientDetails extends ClassFille {

    private String id;
    private String idfactureclient;
    private double qte;
    private double pu;
    private double remises;
    private double tva;
    private String compte;
    private String idproduit;
    private String designation;
    private String idacte;

    public FactureClientDetails() throws Exception {
        this.setNomTable("FACTURECLIENTDETAILS");
        this.setLiaisonMere("idfactureclient");
        super.setNomClasseMere("cinema.facture.FactureClient");
        this.setQte(1);
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("FCLD", "GET_SEQ_FACTURECLIENTDETAILS");
        this.setId(makePK(c));
    }

    @Override
    public String getNomClasseMere() {
        return "cinema.facture.FactureClient";
    }

    @Override
    public String getLiaisonMere() {
        return "idfactureclient";
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getIdfactureclient() == null || this.getIdfactureclient().isEmpty()) throw new Exception("Ligne sans facture");
        if (this.getQte() <= 0) throw new Exception("La quantite doit etre positive");
        if (this.getPu() < 0 || this.getRemises() < 0) throw new Exception("Prix et remise ne peuvent pas etre negatifs");
        if (this.getRemises() > this.getQte() * this.getPu()) throw new Exception("La remise depasse le montant de la ligne");
        this.setDesignation(UtilCinema.tronquer(this.getDesignation(), ConstanteCinema.LONGUEUR_DESIGNATION_LIGNE));
    }

    public double getMontantHT() {
        return this.getQte() * this.getPu() - this.getRemises();
    }

    public double getMontantTTC() {
        return this.getMontantHT() * (1 + this.getTva() / 100.0);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdfactureclient() {
        return idfactureclient;
    }

    public void setIdfactureclient(String idfactureclient) {
        this.idfactureclient = idfactureclient;
    }

    public double getQte() {
        return qte;
    }

    public void setQte(double qte) {
        this.qte = qte;
    }

    public double getPu() {
        return pu;
    }

    public void setPu(double pu) {
        this.pu = pu;
    }

    public double getRemises() {
        return remises;
    }

    public void setRemises(double remises) {
        this.remises = remises;
    }

    public double getTva() {
        return tva;
    }

    public void setTva(double tva) {
        this.tva = tva;
    }

    public String getCompte() {
        return compte;
    }

    public void setCompte(String compte) {
        this.compte = compte;
    }

    public String getIdproduit() {
        return idproduit;
    }

    public void setIdproduit(String idproduit) {
        this.idproduit = idproduit;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getIdacte() {
        return idacte;
    }

    public void setIdacte(String idacte) {
        this.idacte = idacte;
    }

}
