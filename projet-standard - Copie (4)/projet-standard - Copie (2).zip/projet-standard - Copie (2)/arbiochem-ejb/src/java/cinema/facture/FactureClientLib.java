/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.facture;

import bean.CGenUtil;
import cinema.utils.UtilCinema;
import java.sql.Connection;

/**
 * Lecture seule (vue FACTURECLIENT_LIB) : totaux, montant paye, reste a payer, statut IMPAYEE / PARTIELLE / PAYEE.
 */
public class FactureClientLib extends FactureClient {

    private String idclientlib;
    private double montantht;
    private double montantttc;
    private double montantpaye;
    private double resteapayer;
    private String statutpaiement;

    public FactureClientLib() {
        this.setNomTable("FACTURECLIENT_LIB");
    }

    public static FactureClientLib charger(String id, Connection c) throws Exception {
        FactureClientLib[] r = (FactureClientLib[]) CGenUtil.rechercher(new FactureClientLib(), null, null, c, " and id = '" + UtilCinema.id(id) + "'");
        if (r.length == 0) throw new Exception("Facture introuvable");
        return r[0];
    }

    public String getIdclientlib() {
        return idclientlib;
    }

    public void setIdclientlib(String idclientlib) {
        this.idclientlib = idclientlib;
    }

    public double getMontantht() {
        return montantht;
    }

    public void setMontantht(double montantht) {
        this.montantht = montantht;
    }

    public double getMontantttc() {
        return montantttc;
    }

    public void setMontantttc(double montantttc) {
        this.montantttc = montantttc;
    }

    public double getMontantpaye() {
        return montantpaye;
    }

    public void setMontantpaye(double montantpaye) {
        this.montantpaye = montantpaye;
    }

    public double getResteapayer() {
        return resteapayer;
    }

    public void setResteapayer(double resteapayer) {
        this.resteapayer = resteapayer;
    }

    public String getStatutpaiement() {
        return statutpaiement;
    }

    public void setStatutpaiement(String statutpaiement) {
        this.statutpaiement = statutpaiement;
    }

}
