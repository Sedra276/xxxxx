/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.reservation;

import java.sql.Connection;

/**
 * Lecture seule (vue DETAILSRESERVATION_LIB).
 */
public class DetailsReservationLib extends DetailsReservation {

    private String idplacelib;
    private String typeplacelib;
    private String idcategorieclientlib;

    public DetailsReservationLib() throws Exception {
        this.setNomTable("DETAILSRESERVATION_LIB");
    }

    public String getIdplacelib() {
        return idplacelib;
    }

    public void setIdplacelib(String idplacelib) {
        this.idplacelib = idplacelib;
    }

    public String getTypeplacelib() {
        return typeplacelib;
    }

    public void setTypeplacelib(String typeplacelib) {
        this.typeplacelib = typeplacelib;
    }

    public String getIdcategorieclientlib() {
        return idcategorieclientlib;
    }

    public void setIdcategorieclientlib(String idcategorieclientlib) {
        this.idcategorieclientlib = idcategorieclientlib;
    }

}
