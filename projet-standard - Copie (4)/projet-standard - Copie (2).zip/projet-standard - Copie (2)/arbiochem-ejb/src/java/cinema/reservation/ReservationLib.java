/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.reservation;

import java.sql.Connection;

/**
 * Lecture seule (vue CIN_RESERVATION_LIB : uniquement les reservations de seance).
 */
public class ReservationLib extends Reservation {

    private String idclientlib;
    private String idseancelib;
    private String salle;

    public ReservationLib() {
        this.setNomTable("CIN_RESERVATION_LIB");
    }

    public String getIdclientlib() {
        return idclientlib;
    }

    public void setIdclientlib(String idclientlib) {
        this.idclientlib = idclientlib;
    }

    public String getIdseancelib() {
        return idseancelib;
    }

    public void setIdseancelib(String idseancelib) {
        this.idseancelib = idseancelib;
    }

    public String getSalle() {
        return salle;
    }

    public void setSalle(String salle) {
        this.salle = salle;
    }

}
