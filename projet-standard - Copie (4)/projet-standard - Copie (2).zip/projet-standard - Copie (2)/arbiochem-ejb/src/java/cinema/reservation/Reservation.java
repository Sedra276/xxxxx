/*
- Module CINEMA - framework APJ (BICI)
- Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.reservation;

import bean.CGenUtil;
import bean.ClassMere;
import cinema.facture.FactureClient;
import cinema.facture.FactureClientDetails;
import cinema.facture.FactureClientLib;
import cinema.film.Film;
import cinema.seance.PlanSalle;
import cinema.seance.Seance;
import cinema.service.VenteService;
import cinema.tarif.Tarif;
import cinema.utils.ConstanteCinema;
import cinema.utils.UtilCinema;
import cinema.vente.Ticket;
import constante.ConstanteEtat;
import java.sql.Connection;
import java.sql.Date;

/**
- Reservation de seance (ClassMere) = table RESERVATION du standard, etendue (idseance...).
- Cle : prefixe RESA + fonction existante getseqreservation.
-   cree (1) en attente | valide (11) confirmee | cloture : payee (facture + tickets) | annule : annulee / expiree
- Fille : DetailsReservation (liaison idreservation).
 *
- METIER (tout est ici, dans la transaction de l'appelant) :
-   reserver()        : places RESERVEE, AUCUNE facture
-   reserverEtPayer() : places reservees puis payees tout de suite (facture + tickets + encaissement)
-   payer()           : reservation existante -> facture + tickets + encaissement, reservation cloturee
-   confirmer(), annuler(), expirer()
- Le client est facultatif (vide = client de passage).
 */
public class Reservation extends ClassMere {

    private String id;
    private String idclient;
    private Date daty;
    private String remarque;
    private String idseance;
    private int nbplace;
    private double montanttotal;
    private Date dateexpiration;
    private String heureexpiration;

    public Reservation() {
        this.setNomTable("RESERVATION");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("RESA", "getseqreservation");
        this.setId(makePK(c));
    }

    @Override
    public String getLiaisonFille() {
        return "idreservation";
    }

    @Override
    public String getNomClasseFille() {
        return "cinema.reservation.DetailsReservation";
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        // client facultatif : vide = client de passage
        if (this.getIdseance() == null || this.getIdseance().isEmpty()) throw new Exception("La seance est obligatoire");
    }

    /** true si la date/heure d'expiration est depassee. */
    public boolean estExpiree() throws Exception {
        if (this.getDateexpiration() == null) return false;
        return System.currentTimeMillis() > UtilCinema.instant(this.getDateexpiration(), this.getHeureexpiration());
    }

    public DetailsReservation[] getDetails(Connection c) throws Exception {
        return (DetailsReservation[]) CGenUtil.rechercher(new DetailsReservation(), null, null, c,
                " and idreservation = '" + UtilCinema.id(this.getId()) + "' order by id");
    }

    public static Reservation charger(String id, Connection c) throws Exception {
        Reservation[] r = (Reservation[]) CGenUtil.rechercher(new Reservation(), null, null, c,
                " and id = '" + UtilCinema.id(id) + "' and idseance is not null");
        if (r.length == 0) throw new Exception("Reservation introuvable");
        return r[0];
    }


    // =================================================================== METIER

    /**
- Reserver seulement : les places deviennent RESERVEE (indisponibles), aucune facture.
- La facture sera creee au paiement (payer()).
     */
    public static Reservation reserver(String idclient, String idseance, String[] idplaces, String[] idcategories,
                                       Date dateexpiration, String heureexpiration, String u, Connection c) throws Exception {
        return creer(idclient, idseance, idplaces, idcategories, dateexpiration, heureexpiration, false, u, c);
    }

    /**
- Reserver et payer : les places sont reservees puis payees dans la meme transaction
- (facture + 1 ticket par place + encaissement). La reservation est cloturee.
- 
@return la facture creee
     */
    public static FactureClient reserverEtPayer(String idclient, String idseance, String[] idplaces, String[] idcategories,
                                                String idsession, String idmodepaiement, String reference,
                                                String u, Connection c) throws Exception {
        verifierPaiementPossible(idsession, idmodepaiement);
        Reservation r = creer(idclient, idseance, idplaces, idcategories, null, null, true, u, c);
        return r.facturerEtEncaisser(Seance.charger(r.getIdseance(), c), idsession, idmodepaiement, reference, u, c);
    }

    /**
- Payer une reservation en attente ou confirmee : cree la facture (une ligne par place),
- les tickets (les details passent a CONVERTIE par le trigger), encaisse le total
- dans la session de caisse, puis cloture la reservation.
- 
@return la facture creee
     */
    public FactureClient payer(String idsession, String idmodepaiement, String reference, String u, Connection c) throws Exception {
        verifierPaiementPossible(idsession, idmodepaiement);
        if (this.getEtat() == ConstanteEtat.getEtatCloture()) throw new Exception("Reservation deja payee");
        if (this.getEtat() == ConstanteEtat.getEtatAnnuler()) throw new Exception("Reservation annulee");
        if (this.getEtat() == ConstanteEtat.getEtatCreer() && this.estExpiree()) {
            this.liberer(u, c);
            throw new Exception("Reservation expiree : les places ont ete liberees");
        }
        Seance seance = Seance.charger(this.getIdseance(), c);
        seance.verifierVendable();
        return this.facturerEtEncaisser(seance, idsession, idmodepaiement, reference, u, c);
    }

    /** Facture + tickets, encaissement du total, reservation cloturee. */
    private FactureClient facturerEtEncaisser(Seance seance, String idsession, String idmodepaiement, String reference,
                                              String u, Connection c) throws Exception {
        FactureClient f = this.genererFacture(seance, u, c);
        double reste = FactureClientLib.charger(f.getId(), c).getResteapayer();
        if (reste > 0) VenteService.encaisser(f.getId(), idsession, reste, idmodepaiement, reference, u, c);

        this.setEtat(ConstanteEtat.getEtatCloture());
        this.updateToTableWithHisto(u, c);
        return f;
    }

    /** Confirme une reservation en attente (elle reste valable jusqu'au debut de la seance). */
    public void confirmer(String u, Connection c) throws Exception {
        if (this.getEtat() != ConstanteEtat.getEtatCreer()) throw new Exception("Seule une reservation en attente peut etre confirmee");
        if (this.estExpiree()) {
            this.liberer(u, c);
            throw new Exception("Reservation expiree : les places ont ete liberees");
        }
        this.setEtat(ConstanteEtat.getEtatValider());
        this.updateToTableWithHisto(u, c);
    }

    /** Annule une reservation non payee et libere ses places. */
    @Override
    public int annuler(String u, Connection c) throws Exception {
        if (this.getEtat() == ConstanteEtat.getEtatCloture()) throw new Exception("Reservation deja payee : rembourser les tickets");
        if (this.getEtat() == ConstanteEtat.getEtatAnnuler()) throw new Exception("Reservation deja annulee");
        this.liberer(u, c);
        return 1;
    }

    /** Passe la reservation a annule et ses places RESERVEE a LIBEREE. */
    public void liberer(String u, Connection c) throws Exception {
        DetailsReservation[] d = this.getDetails(c);
        for (int i = 0; i < d.length; i++) {
            if (ConstanteCinema.OCC_RESERVEE.equals(d[i].getEtatoccupation())) {
                d[i].setEtatoccupation(ConstanteCinema.OCC_LIBEREE);
                d[i].updateToTableWithHisto(u, c);
            }
        }
        this.setEtat(ConstanteEtat.getEtatAnnuler());
        this.updateToTableWithHisto(u, c);
    }

    /**
- Libere les reservations non payees expirees :
- en attente a leur date/heure d'expiration, confirmees au debut de la seance.
- 
@return nombre de reservations liberees
     */
    public static int expirer(String u, Connection c) throws Exception {
        Reservation[] r = (Reservation[]) CGenUtil.rechercher(new Reservation(), null, null, c,
                " and idseance is not null and etat in (" + ConstanteEtat.getEtatCreer() + "," + ConstanteEtat.getEtatValider() + ")"
                + " and dateexpiration <= " + UtilCinema.dateSql(UtilCinema.aujourdhui()) + " + 1");
        int n = 0;
        for (int i = 0; i < r.length; i++) {
            boolean expiree;
            if (r[i].getEtat() == ConstanteEtat.getEtatCreer()) {
                expiree = r[i].estExpiree();
            } else {
                expiree = System.currentTimeMillis() > Seance.charger(r[i].getIdseance(), c).getDebutMillis();
            }
            if (expiree) {
                r[i].liberer(u, c);
                n++;
            }
        }
        return n;
    }

    // ------------------------------------------------------------------- interne

    private static void verifierPaiementPossible(String idsession, String idmodepaiement) throws Exception {
        if (UtilCinema.estVide(idsession)) throw new Exception("Aucune session de caisse ouverte : ouvrir la caisse pour encaisser");
        if (UtilCinema.estVide(idmodepaiement)) throw new Exception("Choisir le mode de paiement");
    }

    /** Cree la reservation et ses places RESERVEE (index unique en base : anti double reservation). */
    private static Reservation creer(String idclient, String idseance, String[] idplaces, String[] idcategories,
                                     Date dateexpiration, String heureexpiration, boolean payeeToutDeSuite,
                                     String u, Connection c) throws Exception {
        if (idplaces == null || idplaces.length == 0) throw new Exception("Selectionner au moins une place");
        if (idcategories == null || idcategories.length != idplaces.length) throw new Exception("Categorie de client manquante pour une place");

        Seance seance = Seance.charger(idseance, c);
        seance.verifierVendable();

        PlanSalle[] etats = PlanSalle.chargerPlaces(seance.getId(), idplaces, c);
        for (int i = 0; i < etats.length; i++) {
            if (!ConstanteCinema.PL_LIBRE.equals(etats[i].getEtatplace())) {
                throw new Exception("La place " + etats[i].getLibellePlace() + " n'est plus disponible");
            }
        }

        long limite = seance.getDebutMillis() - UtilCinema.minutes(ConstanteCinema.EXPIRATION_AVANT_SEANCE_MINUTES);
        long expiration;
        if (dateexpiration != null) {
            expiration = UtilCinema.instant(dateexpiration, UtilCinema.estVide(heureexpiration) ? "23:59" : heureexpiration);
            if (expiration > limite) expiration = limite;
        } else {
            expiration = Math.min(System.currentTimeMillis() + UtilCinema.minutes(ConstanteCinema.VALIDITE_RESERVATION_HEURES * 60), limite);
        }
        if (payeeToutDeSuite) {
            expiration = Math.max(expiration, seance.getDebutMillis());
        } else if (expiration <= System.currentTimeMillis()) {
            throw new Exception("Trop tard pour une simple reservation : utiliser Reserver et payer");
        }

        Reservation res = new Reservation();
        res.setIdclient(UtilCinema.estVide(idclient) ? null : UtilCinema.id(idclient));
        res.setIdseance(seance.getId());
        res.setDaty(UtilCinema.aujourdhui());
        res.setDateexpiration(UtilCinema.dateDe(expiration));
        res.setHeureexpiration(UtilCinema.heureDe(expiration));
        res.setNbplace(idplaces.length);
        res.setEtat(ConstanteEtat.getEtatCreer());

        double total = 0;
        DetailsReservation[] details = new DetailsReservation[idplaces.length];
        for (int i = 0; i < idplaces.length; i++) {
            PlanSalle p = trouver(etats, idplaces[i]);
            double prix = Tarif.getPrixApplicable(p.getIdtypeplace(), idcategories[i], UtilCinema.aujourdhui(), c);
            
            // REDUCTION DE 50% SI LA SEANCE COMMENCE A 20H00 OU APRES
            if (seance.getHeuredebut() != null && seance.getHeuredebut().compareTo("20:00") >= 0) {
                prix = UtilCinema.arrondi(prix * 0.5);
            }

            DetailsReservation d = new DetailsReservation();
            d.setIdseance(seance.getId());
            d.setIdplace(p.getIdplace());
            d.setIdcategorieclient(UtilCinema.id(idcategories[i]));
            d.setPrix(prix);
            d.setEtatoccupation(ConstanteCinema.OCC_RESERVEE);
            details[i] = d;
            total += prix;
        }
        res.setMontanttotal(UtilCinema.arrondi(total));
        res = (Reservation) res.createObject(u, c);
        for (int i = 0; i < details.length; i++) {
            details[i].setIdreservation(res.getId());
            details[i].createObject(u, c);
        }
        return res;
    }

    /** Facture (1 ligne par place encore RESERVEE, au prix fige) + 1 ticket par place. */
    private FactureClient genererFacture(Seance seance, String u, Connection c) throws Exception {
        DetailsReservation[] d = this.getDetails(c);
        int nb = 0;
        for (int i = 0; i < d.length; i++) if (ConstanteCinema.OCC_RESERVEE.equals(d[i].getEtatoccupation())) nb++;
        if (nb == 0) throw new Exception("Aucune place reservee a payer");

        String[] ids = new String[nb];
        for (int i = 0, k = 0; i < d.length; i++) if (ConstanteCinema.OCC_RESERVEE.equals(d[i].getEtatoccupation())) ids[k++] = d[i].getIdplace();
        PlanSalle[] plan = PlanSalle.chargerPlaces(seance.getId(), ids, c);

        Film film = Film.charger(seance.getIdfilm(), c);
        String libSeance = film.getTitre() + " - " + UtilCinema.formatDate(seance.getDaty()) + " " + seance.getHeuredebut();

        FactureClient f = new FactureClient();
        f.setIdclient(this.getIdclient());
        f.setDaty(UtilCinema.aujourdhui());
        f.setDateecheancepaiement(UtilCinema.aujourdhui());
        f.setDesignation(UtilCinema.tronquer("Billets " + libSeance + " (reservation " + this.getId() + ")", 255));
        f.setTva(ConstanteCinema.TVA_BILLET);
        f.setIdreservation(this.getId());
        f.setEtat(ConstanteEtat.getEtatCreer());
        f = (FactureClient) f.createObject(u, c);

        String heure = UtilCinema.heureCourante();
        for (int i = 0; i < d.length; i++) {
            if (!ConstanteCinema.OCC_RESERVEE.equals(d[i].getEtatoccupation())) continue;
            String lib = d[i].getIdplace();
            for (int k = 0; k < plan.length; k++) if (plan[k].getIdplace().equals(d[i].getIdplace())) lib = plan[k].getLibellePlace();

            FactureClientDetails ligne = new FactureClientDetails();
            ligne.setIdfactureclient(f.getId());
            ligne.setQte(1);
            ligne.setPu(d[i].getPrix());
            ligne.setRemises(0);
            ligne.setTva(ConstanteCinema.TVA_BILLET);
            ligne.setDesignation(UtilCinema.tronquer("Billet " + libSeance + " - place " + lib, 255));
            ligne.setIdacte(seance.getId());
            ligne = (FactureClientDetails) ligne.createObject(u, c);

            Ticket t = new Ticket();
            t.setIdreservation(this.getId());
            t.setIdfactureclientdetails(ligne.getId());
            t.setIdseance(seance.getId());
            t.setIdplace(d[i].getIdplace());
            t.setIdcategorieclient(d[i].getIdcategorieclient());
            t.setPrix(d[i].getPrix());
            t.setCodeunique(UtilCinema.codeTicket());
            t.setStatut(ConstanteCinema.TK_VALIDE);
            t.setDaty(UtilCinema.aujourdhui());
            t.setHeure(heure);
            t.createObject(u, c);
        }

        f.setEtat(ConstanteEtat.getEtatValider());
        f.updateToTableWithHisto(u, c);
        return f;
    }

    private static PlanSalle trouver(PlanSalle[] etats, String idplace) throws Exception {
        for (int i = 0; i < etats.length; i++) {
            if (etats[i].getIdplace().equals(idplace)) return etats[i];
        }
        throw new Exception("Place introuvable : " + idplace);
    }

    // =================================================================== ACCESSEURS

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdclient() {
        return idclient;
    }

    public void setIdclient(String idclient) {
        this.idclient = idclient;
    }

    public Date getDaty() {
        return daty;
    }

    public void setDaty(Date daty) {
        this.daty = daty;
    }

    public String getRemarque() {
        return remarque;
    }

    public void setRemarque(String remarque) {
        this.remarque = remarque;
    }

    public String getIdseance() {
        return idseance;
    }

    public void setIdseance(String idseance) {
        this.idseance = idseance;
    }

    public int getNbplace() {
        return nbplace;
    }

    public void setNbplace(int nbplace) {
        this.nbplace = nbplace;
    }

    public double getMontanttotal() {
        return montanttotal;
    }

    public void setMontanttotal(double montanttotal) {
        this.montanttotal = montanttotal;
    }

    public Date getDateexpiration() {
        return dateexpiration;
    }

    public void setDateexpiration(Date dateexpiration) {
        this.dateexpiration = dateexpiration;
    }

    public String getHeureexpiration() {
        return heureexpiration;
    }

    public void setHeureexpiration(String heureexpiration) {
        this.heureexpiration = heureexpiration;
    }

}