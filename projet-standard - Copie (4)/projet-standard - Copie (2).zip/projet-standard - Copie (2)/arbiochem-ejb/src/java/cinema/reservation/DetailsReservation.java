/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.reservation;

import bean.ClassFille;
import java.sql.Connection;

/**
 * Place reservee (ClassFille de Reservation). prix = prix fige a la reservation.
 * etatoccupation : RESERVEE / CONVERTIE / LIBEREE.
 */
public class DetailsReservation extends ClassFille {

    private String id;
    private String idreservation;
    private String idseance;
    private String idplace;
    private String idcategorieclient;
    private double prix;
    private String etatoccupation;

    public DetailsReservation() throws Exception {
        this.setNomTable("DETAILSRESERVATION");
        this.setLiaisonMere("idreservation");
        super.setNomClasseMere("cinema.reservation.Reservation");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("DRS", "GETSEQDETAILSRESERVATION");
        this.setId(makePK(c));
    }

    @Override
    public String getNomClasseMere() {
        return "cinema.reservation.Reservation";
    }

    @Override
    public String getLiaisonMere() {
        return "idreservation";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdreservation() {
        return idreservation;
    }

    public void setIdreservation(String idreservation) {
        this.idreservation = idreservation;
    }

    public String getIdseance() {
        return idseance;
    }

    public void setIdseance(String idseance) {
        this.idseance = idseance;
    }

    public String getIdplace() {
        return idplace;
    }

    public void setIdplace(String idplace) {
        this.idplace = idplace;
    }

    public String getIdcategorieclient() {
        return idcategorieclient;
    }

    public void setIdcategorieclient(String idcategorieclient) {
        this.idcategorieclient = idcategorieclient;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public String getEtatoccupation() {
        return etatoccupation;
    }

    public void setEtatoccupation(String etatoccupation) {
        this.etatoccupation = etatoccupation;
    }

}
