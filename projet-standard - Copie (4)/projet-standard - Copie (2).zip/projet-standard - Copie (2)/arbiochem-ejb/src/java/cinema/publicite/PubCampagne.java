/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.publicite;

import bean.CGenUtil;
import bean.ClassMere;
import cinema.utils.UtilCinema;
import java.sql.Connection;
import java.sql.Date;

/**
 * Campagne publicitaire (ClassMere) ; fille : PubDiffusion (liaison idcampagne).
 *   cree (1) | validee (11) : diffusions planifiables | cloture : facturee | annule
 */
public class PubCampagne extends ClassMere {

    private String id;
    private String idclient;
    private String designation;
    private Date datedebut;
    private Date datefin;
    private double prixdiffusion;
    private String remarque;

    public PubCampagne() {
        this.setNomTable("PUBCAMPAGNE");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("PCA", "GETSEQPUBCAMPAGNE");
        this.setId(makePK(c));
    }

    @Override
    public String getLiaisonFille() {
        return "idcampagne";
    }

    @Override
    public String getNomClasseFille() {
        return "cinema.publicite.PubDiffusion";
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getIdclient() == null || this.getIdclient().isEmpty()) throw new Exception("L'annonceur est obligatoire");
        if (this.getDatedebut() == null || this.getDatefin() == null) throw new Exception("La periode de la campagne est obligatoire");
        if (this.getDatefin().before(this.getDatedebut())) throw new Exception("La date de fin doit etre apres la date de debut");
        if (this.getPrixdiffusion() < 0) throw new Exception("Le prix par diffusion ne peut pas etre negatif");
    }

    public static PubCampagne charger(String id, Connection c) throws Exception {
        PubCampagne[] r = (PubCampagne[]) CGenUtil.rechercher(new PubCampagne(), null, null, c, " and id = '" + UtilCinema.id(id) + "'");
        if (r.length == 0) throw new Exception("Campagne introuvable");
        return r[0];
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdclient() {
        return idclient;
    }

    public void setIdclient(String idclient) {
        this.idclient = idclient;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Date getDatedebut() {
        return datedebut;
    }

    public void setDatedebut(Date datedebut) {
        this.datedebut = datedebut;
    }

    public Date getDatefin() {
        return datefin;
    }

    public void setDatefin(Date datefin) {
        this.datefin = datefin;
    }

    public double getPrixdiffusion() {
        return prixdiffusion;
    }

    public void setPrixdiffusion(double prixdiffusion) {
        this.prixdiffusion = prixdiffusion;
    }

    public String getRemarque() {
        return remarque;
    }

    public void setRemarque(String remarque) {
        this.remarque = remarque;
    }

}
