/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.publicite;

import java.sql.Connection;
import java.sql.Date;

/**
 * Lecture seule (vue PUBDIFFUSION_LIB).
 */
public class PubDiffusionLib extends PubDiffusion {

    private String idcampagnelib;
    private String idvideolib;
    private int dureesecondes;
    private String idseancelib;
    private Date datyseance;
    private String annonceur;
    private int facturee;

    public PubDiffusionLib() throws Exception {
        this.setNomTable("PUBDIFFUSION_LIB");
    }

    public String getIdcampagnelib() {
        return idcampagnelib;
    }

    public void setIdcampagnelib(String idcampagnelib) {
        this.idcampagnelib = idcampagnelib;
    }

    public String getIdvideolib() {
        return idvideolib;
    }

    public void setIdvideolib(String idvideolib) {
        this.idvideolib = idvideolib;
    }

    public int getDureesecondes() {
        return dureesecondes;
    }

    public void setDureesecondes(int dureesecondes) {
        this.dureesecondes = dureesecondes;
    }

    public String getIdseancelib() {
        return idseancelib;
    }

    public void setIdseancelib(String idseancelib) {
        this.idseancelib = idseancelib;
    }

    public Date getDatyseance() {
        return datyseance;
    }

    public void setDatyseance(Date datyseance) {
        this.datyseance = datyseance;
    }

    public String getAnnonceur() {
        return annonceur;
    }

    public void setAnnonceur(String annonceur) {
        this.annonceur = annonceur;
    }

    public int getFacturee() {
        return facturee;
    }

    public void setFacturee(int facturee) {
        this.facturee = facturee;
    }

}
