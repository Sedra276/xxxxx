/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.publicite;

import bean.ClassMAPTable;
import java.sql.Connection;

/**
 * Spot publicitaire d'un annonceur (annonceur = CLIENT).
 */
public class PubVideo extends ClassMAPTable {

    private String id;
    private String idclient;
    private String titre;
    private int dureesecondes;
    private String fichier;
    private int actif;

    public PubVideo() {
        this.setNomTable("PUBVIDEO");
        this.setActif(1);
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("PVD", "GETSEQPUBVIDEO");
        this.setId(makePK(c));
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getIdclient() == null || this.getIdclient().isEmpty()) throw new Exception("L'annonceur est obligatoire");
        if (this.getTitre() == null || this.getTitre().trim().isEmpty()) throw new Exception("Le titre du spot est obligatoire");
        if (this.getDureesecondes() <= 0) throw new Exception("La duree du spot doit etre positive");
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdclient() {
        return idclient;
    }

    public void setIdclient(String idclient) {
        this.idclient = idclient;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public int getDureesecondes() {
        return dureesecondes;
    }

    public void setDureesecondes(int dureesecondes) {
        this.dureesecondes = dureesecondes;
    }

    public String getFichier() {
        return fichier;
    }

    public void setFichier(String fichier) {
        this.fichier = fichier;
    }

    public int getActif() {
        return actif;
    }

    public void setActif(int actif) {
        this.actif = actif;
    }

}
