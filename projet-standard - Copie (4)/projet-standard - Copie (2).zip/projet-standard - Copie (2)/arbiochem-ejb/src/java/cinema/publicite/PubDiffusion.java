/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.publicite;

import bean.CGenUtil;
import bean.ClassFille;
import cinema.utils.ConstanteCinema;
import cinema.utils.UtilCinema;
import java.sql.Connection;

/**
 * Passage d'un spot avant une seance (ClassFille de PubCampagne).
 * statut : PREVUE / DIFFUSEE / ANNULEE. prix fige a la planification (prix de la campagne par defaut).
 */
public class PubDiffusion extends ClassFille {

    private String id;
    private String idcampagne;
    private String idvideo;
    private String idseance;
    private int ordre;
    private double prix;
    private String statut;

    public PubDiffusion() throws Exception {
        this.setNomTable("PUBDIFFUSION");
        this.setLiaisonMere("idcampagne");
        super.setNomClasseMere("cinema.publicite.PubCampagne");
        this.setStatut(ConstanteCinema.PUB_PREVUE);
        this.setOrdre(1);
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("PDI", "GETSEQPUBDIFFUSION");
        this.setId(makePK(c));
    }

    @Override
    public String getNomClasseMere() {
        return "cinema.publicite.PubCampagne";
    }

    @Override
    public String getLiaisonMere() {
        return "idcampagne";
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getIdvideo() == null || this.getIdvideo().isEmpty()) throw new Exception("Le spot est obligatoire");
        if (this.getIdseance() == null || this.getIdseance().isEmpty()) throw new Exception("La seance est obligatoire");
        if (this.getStatut() == null || this.getStatut().isEmpty()) this.setStatut(ConstanteCinema.PUB_PREVUE);
        if (this.getPrix() <= 0 && this.getIdcampagne() != null && !this.getIdcampagne().isEmpty()) {
            this.setPrix(PubCampagne.charger(this.getIdcampagne(), c).getPrixdiffusion());
        }
    }

    public static PubDiffusion charger(String id, Connection c) throws Exception {
        PubDiffusion[] r = (PubDiffusion[]) CGenUtil.rechercher(new PubDiffusion(), null, null, c, " and id = '" + UtilCinema.id(id) + "'");
        if (r.length == 0) throw new Exception("Diffusion introuvable");
        return r[0];
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdcampagne() {
        return idcampagne;
    }

    public void setIdcampagne(String idcampagne) {
        this.idcampagne = idcampagne;
    }

    public String getIdvideo() {
        return idvideo;
    }

    public void setIdvideo(String idvideo) {
        this.idvideo = idvideo;
    }

    public String getIdseance() {
        return idseance;
    }

    public void setIdseance(String idseance) {
        this.idseance = idseance;
    }

    public int getOrdre() {
        return ordre;
    }

    public void setOrdre(int ordre) {
        this.ordre = ordre;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

}
