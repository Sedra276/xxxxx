/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.publicite;

import java.sql.Connection;

/**
 * Lecture seule (vue PUBCAMPAGNE_LIB).
 */
public class PubCampagneLib extends PubCampagne {

    private String idclientlib;
    private int nbdiffusion;
    private double montant;

    public PubCampagneLib() {
        this.setNomTable("PUBCAMPAGNE_LIB");
    }

    public String getIdclientlib() {
        return idclientlib;
    }

    public void setIdclientlib(String idclientlib) {
        this.idclientlib = idclientlib;
    }

    public int getNbdiffusion() {
        return nbdiffusion;
    }

    public void setNbdiffusion(int nbdiffusion) {
        this.nbdiffusion = nbdiffusion;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

}
