/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.publicite;

import java.sql.Connection;

/**
 * Lecture seule (vue PUBVIDEO_LIB).
 */
public class PubVideoLib extends PubVideo {

    private String idclientlib;

    public PubVideoLib() {
        this.setNomTable("PUBVIDEO_LIB");
    }

    public String getIdclientlib() {
        return idclientlib;
    }

    public void setIdclientlib(String idclientlib) {
        this.idclientlib = idclientlib;
    }

}
