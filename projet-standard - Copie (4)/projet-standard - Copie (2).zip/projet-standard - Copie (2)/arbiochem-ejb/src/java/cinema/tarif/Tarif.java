/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.tarif;

import bean.CGenUtil;
import bean.ClassMAPTable;
import cinema.utils.UtilCinema;
import java.sql.Connection;
import java.sql.Date;

/**
 * Tarif par type de place x categorie de client, sur une periode.
 * Pour changer un prix : creer un NOUVEAU tarif (nouvelle date de debut) et cloturer l'ancien (datefin),
 * les ventes passees gardent leur prix (fige dans TICKET.prix / DETAILSRESERVATION.prix).
 */
public class Tarif extends ClassMAPTable {

    private String id;
    private String idtypeplace;
    private String idcategorieclient;
    private double prix;
    private int actif;
    private Date datedebut;
    private Date datefin;

    public Tarif() {
        this.setNomTable("TARIF");
        this.setActif(1);
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("TAR", "GETSEQTARIF");
        this.setId(makePK(c));
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getIdtypeplace() == null || this.getIdtypeplace().isEmpty()) throw new Exception("Le type de place est obligatoire");
        if (this.getIdcategorieclient() == null || this.getIdcategorieclient().isEmpty()) throw new Exception("La categorie de client est obligatoire");
        if (this.getPrix() < 0) throw new Exception("Le prix ne peut pas etre negatif");
        if (this.getDatedebut() != null && this.getDatefin() != null && this.getDatefin().before(this.getDatedebut())) {
            throw new Exception("La date de fin doit etre apres la date de debut");
        }
        if (this.getActif() == 1) this.verifierChevauchement(c);
    }

    @Override
    public int updateObject(String u, Connection c) throws Exception {
        this.controler(c);
        return super.updateObject(u, c);
    }

    /** Deux tarifs actifs du meme couple ne doivent pas couvrir la meme periode. */
    private void verifierChevauchement(Connection c) throws Exception {
        String debut = this.getDatedebut() == null ? "TO_DATE('01/01/1900','DD/MM/YYYY')" : UtilCinema.dateSql(this.getDatedebut());
        String fin = this.getDatefin() == null ? "TO_DATE('31/12/9999','DD/MM/YYYY')" : UtilCinema.dateSql(this.getDatefin());
        String w = " and actif = 1"
                + " and idtypeplace = '" + UtilCinema.id(this.getIdtypeplace()) + "'"
                + " and idcategorieclient = '" + UtilCinema.id(this.getIdcategorieclient()) + "'"
                + " and NVL(datedebut, TO_DATE('01/01/1900','DD/MM/YYYY')) <= " + fin
                + " and NVL(datefin, TO_DATE('31/12/9999','DD/MM/YYYY')) >= " + debut;
        if (this.getId() != null && !this.getId().isEmpty()) w += " and id <> '" + UtilCinema.id(this.getId()) + "'";
        Object[] r = CGenUtil.rechercher(new Tarif(), null, null, c, w);
        if (r.length > 0) {
            throw new Exception("Un tarif actif existe deja pour ce type de place et cette categorie sur cette periode ("
                    + ((Tarif) r[0]).getId() + ")");
        }
    }

    /**
     * Prix applicable a une date pour un type de place et une categorie de client.
     * Le tarif retenu est le tarif actif dont la periode couvre la date ; s'il y en a plusieurs,
     * celui qui a la date de debut la plus recente.
     */
    public static double getPrixApplicable(String idtypeplace, String idcategorieclient, Date daty, Connection c) throws Exception {
        String d = UtilCinema.dateSql(daty == null ? UtilCinema.aujourdhui() : daty);
        Tarif[] r = (Tarif[]) CGenUtil.rechercher(new Tarif(), null, null, c,
                " and actif = 1"
                + " and idtypeplace = '" + UtilCinema.id(idtypeplace) + "'"
                + " and idcategorieclient = '" + UtilCinema.id(idcategorieclient) + "'"
                + " and (datedebut is null or datedebut <= " + d + ")"
                + " and (datefin is null or datefin >= " + d + ")"
                + " order by datedebut desc nulls last");
        if (r.length == 0) {
            throw new Exception("Aucun tarif applicable pour ce type de place et cette categorie de client");
        }
        return r[0].getPrix();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdtypeplace() {
        return idtypeplace;
    }

    public void setIdtypeplace(String idtypeplace) {
        this.idtypeplace = idtypeplace;
    }

    public String getIdcategorieclient() {
        return idcategorieclient;
    }

    public void setIdcategorieclient(String idcategorieclient) {
        this.idcategorieclient = idcategorieclient;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public int getActif() {
        return actif;
    }

    public void setActif(int actif) {
        this.actif = actif;
    }

    public Date getDatedebut() {
        return datedebut;
    }

    public void setDatedebut(Date datedebut) {
        this.datedebut = datedebut;
    }

    public Date getDatefin() {
        return datefin;
    }

    public void setDatefin(Date datefin) {
        this.datefin = datefin;
    }

}
