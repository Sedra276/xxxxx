/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.tarif;

import bean.ClassMAPTable;
import java.sql.Connection;

/**
 * Configuration liant deux tarifs par un pourcentage (reprise du script initial ;
 * regle d'application a preciser avant de l'utiliser dans le calcul du prix).
 */
public class ConfigurationTarif extends ClassMAPTable {

    private String id;
    private String idtarif1;
    private String idtarif2;
    private double pourcentage;
    private int actif;

    public ConfigurationTarif() {
        this.setNomTable("CONFIGURATIONTARIF");
        this.setActif(1);
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("CTA", "GETSEQCONFIGURATIONTARIF");
        this.setId(makePK(c));
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getIdtarif1() == null || this.getIdtarif2() == null) throw new Exception("Les deux tarifs sont obligatoires");
        if (this.getIdtarif1().equals(this.getIdtarif2())) throw new Exception("Les deux tarifs doivent etre differents");
        if (this.getPourcentage() < 0 || this.getPourcentage() > 100) throw new Exception("Le pourcentage doit etre entre 0 et 100");
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdtarif1() {
        return idtarif1;
    }

    public void setIdtarif1(String idtarif1) {
        this.idtarif1 = idtarif1;
    }

    public String getIdtarif2() {
        return idtarif2;
    }

    public void setIdtarif2(String idtarif2) {
        this.idtarif2 = idtarif2;
    }

    public double getPourcentage() {
        return pourcentage;
    }

    public void setPourcentage(double pourcentage) {
        this.pourcentage = pourcentage;
    }

    public int getActif() {
        return actif;
    }

    public void setActif(int actif) {
        this.actif = actif;
    }

}
