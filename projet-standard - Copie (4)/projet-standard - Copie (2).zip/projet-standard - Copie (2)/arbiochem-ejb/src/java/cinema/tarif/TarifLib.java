/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.tarif;

import java.sql.Connection;

/**
 * Lecture seule (vue TARIF_LIB).
 */
public class TarifLib extends Tarif {

    private String idtypeplacelib;
    private String idcategorieclientlib;

    public TarifLib() {
        this.setNomTable("TARIF_LIB");
    }

    public String getIdtypeplacelib() {
        return idtypeplacelib;
    }

    public void setIdtypeplacelib(String idtypeplacelib) {
        this.idtypeplacelib = idtypeplacelib;
    }

    public String getIdcategorieclientlib() {
        return idcategorieclientlib;
    }

    public void setIdcategorieclientlib(String idcategorieclientlib) {
        this.idcategorieclientlib = idcategorieclientlib;
    }

}
