/*
 * Module CINEMA - framework APJ (BICI)
 */
package cinema.service;

import cinema.caisse.MvtCaisseCinema;
import cinema.caisse.PaiementFacture;
import cinema.caisse.SessionCaisse;
import cinema.facture.FactureClient;
import cinema.facture.FactureClientDetails;
import cinema.facture.FactureClientLib;
import cinema.film.Film;
import cinema.reservation.DetailsReservation;
import cinema.reservation.Reservation;
import cinema.seance.PlanSalle;
import cinema.seance.Seance;
import cinema.tarif.Tarif;
import cinema.utils.ConstanteCinema;
import cinema.utils.UtilCinema;
import cinema.vente.Ticket;
import constante.ConstanteEtat;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

/**
 * Vente de billets, encaissement, remboursement.
 * Une vente = 1 facture (FACTURECLIENT) + 1 ligne par billet (FACTURECLIENTDETAILS) + 1 ticket par place.
 * Toutes les methodes travaillent dans la transaction de l'appelant.
 */
public class VenteService {

    /**
     * Vente directe (sans reservation) au guichet.
     * @param idclient peut etre vide (client de passage)
     */
   public static FactureClient vendreDirect(String idclient, String idseance, String[] idplaces, String[] idcategories,
                                             String u, Connection c) throws Exception {
        if (idplaces == null || idplaces.length == 0) throw new Exception("Selectionner au moins une place");
        if (idcategories == null || idcategories.length != idplaces.length) throw new Exception("Categorie de client manquante pour une place");
        Seance seance = Seance.charger(idseance, c);
        seance.verifierVendable();

        PlanSalle[] etats = PlanSalle.chargerPlaces(idseance, idplaces, c);
        List<LigneVente> lignes = new ArrayList<LigneVente>();
        for (int i = 0; i < idplaces.length; i++) {
            PlanSalle p = null;
            for (int k = 0; k < etats.length; k++) if (etats[k].getIdplace().equals(idplaces[i])) p = etats[k];
            if (p == null) throw new Exception("Place introuvable");
            if (!ConstanteCinema.PL_LIBRE.equals(p.getEtatplace())) {
                throw new Exception("La place " + p.getLibellePlace() + " n'est plus disponible");
            }
            double prix = Tarif.getPrixApplicable(p.getIdtypeplace(), idcategories[i], UtilCinema.aujourdhui(), c);
            
            // REDUCTION DE 50% A PARTIR DE 20h00
            if (seance.getHeuredebut() != null && seance.getHeuredebut().compareTo("20:00") >= 0) {
                prix = UtilCinema.arrondi(prix * 0.5);
            }

            lignes.add(new LigneVente(p.getIdplace(), p.getLibellePlace(), UtilCinema.id(idcategories[i]), prix));
        }
        return creerVente(idclient, seance, null, lignes, u, c);
    }

    /**
     * Ancien point d'entree : le paiement d'une reservation est desormais Reservation.payer()
     * (facture + tickets + encaissement). Conserve pour compatibilite.
     */
    public static FactureClient payerReservation(String idreservation, String idsession, String idmodepaiement,
                                                 String reference, String u, Connection c) throws Exception {
        return Reservation.charger(idreservation, c).payer(idsession, idmodepaiement, reference, u, c);
    }

    private static FactureClient creerVente(String idclient, Seance seance, String idreservation, List<LigneVente> lignes,
                                            String u, Connection c) throws Exception {
        Film film = Film.charger(seance.getIdfilm(), c);
        String libSeance = film.getTitre() + " - " + UtilCinema.formatDate(seance.getDaty()) + " " + seance.getHeuredebut();

        FactureClient f = new FactureClient();
        f.setIdclient(UtilCinema.estVide(idclient) ? null : UtilCinema.id(idclient));
        f.setDaty(UtilCinema.aujourdhui());
        f.setDateecheancepaiement(UtilCinema.aujourdhui());
        f.setDesignation(UtilCinema.tronquer("Billets " + libSeance, 255));
        f.setTva(ConstanteCinema.TVA_BILLET);
        f.setIdreservation(idreservation);
        f.setEtat(ConstanteEtat.getEtatCreer());
        f = (FactureClient) f.createObject(u, c);

        String heure = UtilCinema.heureCourante();
        for (int i = 0; i < lignes.size(); i++) {
            LigneVente l = lignes.get(i);
            FactureClientDetails ligne = new FactureClientDetails();
            ligne.setIdfactureclient(f.getId());
            ligne.setQte(1);
            ligne.setPu(l.prix);
            ligne.setRemises(0);
            ligne.setTva(ConstanteCinema.TVA_BILLET);
            ligne.setDesignation("Billet " + libSeance + " - place " + l.libellePlace);
            ligne.setIdacte(seance.getId());
            ligne = (FactureClientDetails) ligne.createObject(u, c);

            Ticket t = new Ticket();
            t.setIdreservation(idreservation);
            t.setIdfactureclientdetails(ligne.getId());
            t.setIdseance(seance.getId());
            t.setIdplace(l.idplace);
            t.setIdcategorieclient(l.idcategorie);
            t.setPrix(l.prix);
            
            t.setCodeunique(UtilCinema.codeTicket());
            t.setStatut(ConstanteCinema.TK_VALIDE);
            t.setDaty(UtilCinema.aujourdhui());
            t.setHeure(heure);
            t.createObject(u, c);   // index unique en base : anti double vente
        }

        f.setEtat(ConstanteEtat.getEtatValider());
        f.updateToTableWithHisto(u, c);
        return f;
    }

    /**
     * Enregistre un paiement (partiel ou total) sur une facture validee :
     * PAIEMENTFACTURE + mouvement de caisse du poulet (credit), dans la session ouverte.
     * La facture passe a cloture quand elle est soldee.
     */
    public static PaiementFacture encaisser(String idfacture, String idsession, double montant, String idmodepaiement,
                                            String reference, String u, Connection c) throws Exception {
        if (montant <= 0) throw new Exception("Le montant doit etre positif");
        if (UtilCinema.estVide(idmodepaiement)) throw new Exception("Choisir le mode de paiement");
        SessionCaisse session = SessionCaisse.charger(idsession, c);
        if (!session.estOuverte()) throw new Exception("La session de caisse est fermee");

        FactureClientLib f = FactureClientLib.charger(idfacture, c);
        if (f.getEtat() == ConstanteEtat.getEtatAnnuler()) throw new Exception("Facture annulee");
        if (f.getEtat() < ConstanteEtat.getEtatValider()) throw new Exception("La facture doit etre validee avant paiement");
        double reste = UtilCinema.arrondi(f.getResteapayer());
        if (reste <= 0) throw new Exception("Cette facture est deja payee");
        if (UtilCinema.arrondi(montant) > reste) throw new Exception("Le montant depasse le reste a payer (" + reste + ")");

        String heure = UtilCinema.heureCourante();
        PaiementFacture p = new PaiementFacture();
        p.setIdfactureclient(f.getId());
        p.setIdsessioncaisse(session.getId());
        p.setMontant(UtilCinema.arrondi(montant));
   
        p.setIdmodepaiement(UtilCinema.id(idmodepaiement));
        p.setReference(UtilCinema.tronquer(reference, 150));
        p.setDaty(UtilCinema.aujourdhui());
        p.setHeure(heure);
        p = (PaiementFacture) p.createObject(u, c);

        MvtCaisseCinema m = new MvtCaisseCinema();
        m.setIdCaisse(session.getIdcaisse());'h` '
        m.setIdsessioncaisse(session.getId());
        m.setDaty(UtilCinema.aujourdhui());
        m.setHeure(heure);
        m.setCredit(p.getMontant());
        m.setDebit(0);
        m.setDesignation("Reglement facture " + f.getId());
        // pas d'idOrigine : MvtCaisse.validerObject chercherait une ecriture comptable de vente (lettrage)
        // pour cet id et planterait (NullPointerException dans FactureCF.getEcritureAvecFille).
        // Le lien paiement -> mouvement est garde par PAIEMENTFACTURE.IDMOUVEMENTCAISSE.
        m.setIdModePaiement(p.getIdmodepaiement());
        // pas de tiers sur le mouvement de caisse : paiement simple (client de passage accepte)
        m.createObject(u, c);
        m.validerObject(u, c);

        p.setIdmouvementcaisse(m.getId());
        p.updateToTableWithHisto(u, c);

        if (UtilCinema.arrondi(reste - p.getMontant()) <= 0) {
            FactureClient fc = FactureClient.charger(f.getId(), c);
            fc.setEtat(ConstanteEtat.getEtatCloture());
            fc.updateToTableWithHisto(u, c);
        }
        return p;
    }

    /**
     * Rembourse un ticket VALIDE avant la seance : ticket REMBOURSE (la place redevient libre),
     * mouvement de caisse en debit. La facture d'origine n'est pas modifiee (historique conserve).
     */
    public static void rembourserTicket(String idticket, String idsession, String motif, String u, Connection c) throws Exception {
        Ticket t = Ticket.charger(idticket, c);
        if (!ConstanteCinema.TK_VALIDE.equals(t.getStatut())) throw new Exception("Seul un ticket valide peut etre rembourse");
        Seance s = Seance.charger(t.getIdseance(), c);
        long limite = s.getDebutMillis() - UtilCinema.minutes(ConstanteCinema.REMBOURSEMENT_AVANT_SEANCE_MINUTES);
        if (s.getEtat() != ConstanteEtat.getEtatAnnuler() && System.currentTimeMillis() > limite) {
            throw new Exception("Remboursement impossible moins de " + ConstanteCinema.REMBOURSEMENT_AVANT_SEANCE_MINUTES + " minutes avant la seance");
        }
        SessionCaisse session = SessionCaisse.charger(idsession, c);
        if (!session.estOuverte()) throw new Exception("La session de caisse est fermee");

        t.setStatut(ConstanteCinema.TK_REMBOURSE);
        t.updateToTableWithHisto(u, c);

        MvtCaisseCinema m = new MvtCaisseCinema();
        m.setIdCaisse(session.getIdcaisse());
        m.setIdsessioncaisse(session.getId());
        m.setDaty(UtilCinema.aujourdhui());
        m.setHeure(UtilCinema.heureCourante());
        m.setDebit(t.getPrix());
        m.setCredit(0);
        m.setDesignation(UtilCinema.tronquer("Remboursement ticket " + t.getId()
                + (UtilCinema.estVide(motif) ? "" : " : " + motif), 255));
        // pas d'idOrigine (meme raison que pour l'encaissement) : le ticket est cite dans la designation
        m.createObject(u, c);
        m.validerObject(u, c);
    }

    /** Controle a l'entree de la salle : le ticket passe a UTILISE. */
    public static Ticket utiliserTicket(String codeunique, String u, Connection c) throws Exception {
        Ticket t = Ticket.chargerParCode(codeunique, c);
        if (ConstanteCinema.TK_UTILISE.equals(t.getStatut())) throw new Exception("Ticket deja utilise");
        if (!ConstanteCinema.TK_VALIDE.equals(t.getStatut())) throw new Exception("Ticket non valide (" + t.getStatut() + ")");
        t.setStatut(ConstanteCinema.TK_UTILISE);
        t.updateToTableWithHisto(u, c);
        return t;
    }

    private static class LigneVente {
        String idplace;
        String libellePlace;
        String idcategorie;
        double prix;

        LigneVente(String idplace, String libellePlace, String idcategorie, double prix) {
            this.idplace = idplace;
            this.libellePlace = libellePlace;
            this.idcategorie = idcategorie;
            this.prix = prix;
        }
    }
}
