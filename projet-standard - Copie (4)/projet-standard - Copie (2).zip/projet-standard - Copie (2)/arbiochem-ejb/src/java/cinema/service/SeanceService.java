/*
 * Module CINEMA - framework APJ (BICI)
 */
package cinema.service;

import bean.CGenUtil;
import cinema.reservation.Reservation;
import cinema.seance.Seance;
import cinema.utils.ConstanteCinema;
import cinema.utils.UtilCinema;
import cinema.vente.Ticket;
import constante.ConstanteEtat;
import java.sql.Connection;

/**
 * Annulation d'une seance : libere les reservations ; refuse s'il reste des tickets valides
 * (il faut d'abord les rembourser, un remboursement est un mouvement de caisse).
 */
public class SeanceService {

    public static void annuler(String idseance, String u, Connection c) throws Exception {
        Seance s = Seance.charger(idseance, c);
        if (s.getEtat() == ConstanteEtat.getEtatAnnuler()) throw new Exception("Seance deja annulee");
        Object[] tickets = CGenUtil.rechercher(new Ticket(), null, null, c,
                " and idseance = '" + UtilCinema.id(idseance) + "' and statut in ('" + ConstanteCinema.TK_VALIDE + "','" + ConstanteCinema.TK_UTILISE + "')");
        if (tickets.length > 0) {
            throw new Exception(tickets.length + " ticket(s) vendu(s) : les rembourser avant d'annuler la seance");
        }
        Reservation[] r = (Reservation[]) CGenUtil.rechercher(new Reservation(), null, null, c,
                " and idseance = '" + UtilCinema.id(idseance) + "' and etat in (" + ConstanteEtat.getEtatCreer() + "," + ConstanteEtat.getEtatValider() + ")");
        for (int i = 0; i < r.length; i++) {
            ReservationService.liberer(r[i], u, c);
        }
        s.setEtat(ConstanteEtat.getEtatAnnuler());
        s.updateToTableWithHisto(u, c);
    }
}
