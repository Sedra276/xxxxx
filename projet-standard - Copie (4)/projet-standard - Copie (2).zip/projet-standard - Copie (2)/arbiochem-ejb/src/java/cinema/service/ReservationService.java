/*
 * Module CINEMA - framework APJ (BICI)
 */
package cinema.service;

import cinema.facture.FactureClient;
import cinema.reservation.Reservation;
import java.sql.Connection;
import java.sql.Date;

/**
 * Facade conservee pour compatibilite (scheduler, anciennes pages).
 * TOUT le metier des reservations est dans cinema.reservation.Reservation.
 */
public class ReservationService {

    public static Reservation reserver(String idclient, String idseance, String[] idplaces, String[] idcategories,
                                       Date dateexpiration, String heureexpiration, String u, Connection c) throws Exception {
        return Reservation.reserver(idclient, idseance, idplaces, idcategories, dateexpiration, heureexpiration, u, c);
    }

    public static FactureClient reserverEtPayer(String idclient, String idseance, String[] idplaces, String[] idcategories,
                                                String idsession, String idmodepaiement, String reference,
                                                String u, Connection c) throws Exception {
        return Reservation.reserverEtPayer(idclient, idseance, idplaces, idcategories, idsession, idmodepaiement, reference, u, c);
    }

    public static FactureClient payer(String idreservation, String idsession, String idmodepaiement, String reference,
                                      String u, Connection c) throws Exception {
        return Reservation.charger(idreservation, c).payer(idsession, idmodepaiement, reference, u, c);
    }

    public static void confirmer(String idreservation, String u, Connection c) throws Exception {
        Reservation.charger(idreservation, c).confirmer(u, c);
    }

    public static void annuler(String idreservation, String u, Connection c) throws Exception {
        Reservation.charger(idreservation, c).annuler(u, c);
    }

    public static int expirer(String u, Connection c) throws Exception {
        return Reservation.expirer(u, c);
    }
}
