/*
 * Module CINEMA - framework APJ (BICI)
 */
package cinema.service;

import bean.CGenUtil;
import caisse.Caisse;
import cinema.caisse.MvtCaisseCinema;
import cinema.caisse.SessionCaisse;
import cinema.caisse.SessionCaisseLib;
import cinema.utils.UtilCinema;
import constante.ConstanteEtat;
import java.sql.Connection;

/**
 * Ouverture / fermeture des sessions de caisse et decaissements.
 * La caisse elle-meme est une caisse du poulet (table CAISSE).
 */
public class CaisseService {

    public static SessionCaisse ouvrir(String idcaisse, double montantinitial, String u, Connection c) throws Exception {
        if (montantinitial < 0) throw new Exception("Le fond de caisse ne peut pas etre negatif");
        Object[] caisses = CGenUtil.rechercher(new Caisse(), null, null, c, " and id = '" + UtilCinema.id(idcaisse) + "'");
        if (caisses.length == 0) throw new Exception("Caisse introuvable");
        Object[] ouvertes = CGenUtil.rechercher(new SessionCaisse(), null, null, c,
                " and etat = 1 and idcaisse = '" + UtilCinema.id(idcaisse) + "'");
        if (ouvertes.length > 0) throw new Exception("Une session est deja ouverte sur cette caisse (" + ((SessionCaisse) ouvertes[0]).getId() + ")");
        if (SessionCaisse.getSessionOuverteUtilisateur(u, c) != null) throw new Exception("Vous avez deja une session de caisse ouverte");

        SessionCaisse s = new SessionCaisse();
        s.setIdcaisse(idcaisse);
        s.setIdutilisateur(u);
        s.setDateouverture(UtilCinema.aujourdhui());
        s.setHeureouverture(UtilCinema.heureCourante());
        s.setMontantinitial(UtilCinema.arrondi(montantinitial));
        s.setEtat(ConstanteEtat.getEtatCreer());
        return (SessionCaisse) s.createObject(u, c);
    }

    /** Ferme la session : saisie du montant reellement compte ; l'ecart est calcule par la vue. */
    public static SessionCaisseLib fermer(String idsession, double montantreel, String remarque, String u, Connection c) throws Exception {
        SessionCaisse s = SessionCaisse.charger(idsession, c);
        if (!s.estOuverte()) throw new Exception("Session deja fermee");
        if (montantreel < 0) throw new Exception("Le montant compte ne peut pas etre negatif");
        s.setDatefermeture(UtilCinema.aujourdhui());
        s.setHeurefermeture(UtilCinema.heureCourante());
        s.setMontantreel(UtilCinema.arrondi(montantreel));
        s.setRemarque(UtilCinema.tronquer(remarque, 500));
        s.setEtat(ConstanteEtat.getEtatCloture());
        s.updateToTableWithHisto(u, c);
        SessionCaisseLib[] r = (SessionCaisseLib[]) CGenUtil.rechercher(new SessionCaisseLib(), null, null, c,
                " and id = '" + UtilCinema.id(idsession) + "'");
        return r.length == 0 ? null : r[0];
    }

    /** Sortie d'argent manuelle (achat, depense...) sur la session ouverte. */
    public static void decaisser(String idsession, double montant, String motif, String u, Connection c) throws Exception {
        if (montant <= 0) throw new Exception("Le montant doit etre positif");
        if (UtilCinema.estVide(motif)) throw new Exception("Le motif du decaissement est obligatoire");
        SessionCaisseLib[] r = (SessionCaisseLib[]) CGenUtil.rechercher(new SessionCaisseLib(), null, null, c,
                " and id = '" + UtilCinema.id(idsession) + "'");
        if (r.length == 0) throw new Exception("Session de caisse introuvable");
        if (!r[0].estOuverte()) throw new Exception("La session de caisse est fermee");
        if (montant > r[0].getMontanttheorique()) throw new Exception("Montant superieur au solde de la caisse (" + r[0].getMontanttheorique() + ")");

        MvtCaisseCinema m = new MvtCaisseCinema();
        m.setIdCaisse(r[0].getIdcaisse());
        m.setIdsessioncaisse(r[0].getId());
        m.setDaty(UtilCinema.aujourdhui());
        m.setHeure(UtilCinema.heureCourante());
        m.setDebit(UtilCinema.arrondi(montant));
        m.setCredit(0);
        m.setDesignation(UtilCinema.tronquer("Decaissement : " + motif, 255));
        m.createObject(u, c);
        m.validerObject(u, c);
    }
}
