/*
 * Module CINEMA - framework APJ (BICI)
 */
package cinema.service;

import bean.CGenUtil;
import cinema.facture.FactureClient;
import cinema.facture.FactureClientDetails;
import cinema.publicite.PubCampagne;
import cinema.publicite.PubDiffusionLib;
import cinema.publicite.PubDiffusion;
import cinema.utils.ConstanteCinema;
import cinema.utils.UtilCinema;
import constante.ConstanteEtat;
import java.sql.Connection;

/**
 * Publicite : suivi des diffusions et facturation des campagnes.
 * La facture publicitaire utilise FACTURECLIENT / FACTURECLIENTDETAILS (idacte = id de la diffusion),
 * son paiement passe par VenteService.encaisser, comme une facture de billets.
 */
public class PubliciteService {

    public static void changerStatutDiffusion(String iddiffusion, String statut, String u, Connection c) throws Exception {
        if (!ConstanteCinema.PUB_DIFFUSEE.equals(statut) && !ConstanteCinema.PUB_ANNULEE.equals(statut) && !ConstanteCinema.PUB_PREVUE.equals(statut)) {
            throw new Exception("Statut de diffusion invalide");
        }
        PubDiffusion d = PubDiffusion.charger(iddiffusion, c);
        Object[] facturee = CGenUtil.rechercher(new FactureClientDetails(), null, null, c, " and idacte = '" + UtilCinema.id(iddiffusion) + "'");
        if (facturee.length > 0 && ConstanteCinema.PUB_ANNULEE.equals(statut)) {
            throw new Exception("Diffusion deja facturee : impossible de l'annuler");
        }
        d.setStatut(statut);
        d.updateToTableWithHisto(u, c);
    }

    /**
     * Facture toutes les diffusions non annulees et non encore facturees d'une campagne validee.
     * @return la facture creee (validee, a encaisser)
     */
    public static FactureClient facturerCampagne(String idcampagne, String u, Connection c) throws Exception {
        PubCampagne camp = PubCampagne.charger(idcampagne, c);
        if (camp.getEtat() != ConstanteEtat.getEtatValider()) throw new Exception("La campagne doit etre validee pour etre facturee");
        PubDiffusionLib[] d = (PubDiffusionLib[]) CGenUtil.rechercher(new PubDiffusionLib(), null, null, c,
                " and idcampagne = '" + UtilCinema.id(idcampagne) + "' and statut <> '" + ConstanteCinema.PUB_ANNULEE + "' and facturee = 0 order by datyseance, ordre");
        if (d.length == 0) throw new Exception("Aucune diffusion a facturer");

        FactureClient f = new FactureClient();
        f.setIdclient(camp.getIdclient());
        f.setDaty(UtilCinema.aujourdhui());
        f.setDateecheancepaiement(camp.getDatefin());
        f.setDesignation(UtilCinema.tronquer("Publicite - " + camp.getDesignation(), 255));
        f.setTva(0);
        f.setEtat(ConstanteEtat.getEtatCreer());
        f = (FactureClient) f.createObject(u, c);

        for (int i = 0; i < d.length; i++) {
            FactureClientDetails l = new FactureClientDetails();
            l.setIdfactureclient(f.getId());
            l.setQte(1);
            l.setPu(d[i].getPrix());
            l.setRemises(0);
            l.setTva(0);
            l.setDesignation("Diffusion " + d[i].getIdvideolib() + " - " + d[i].getIdseancelib());
            l.setIdacte(d[i].getId());
            l.createObject(u, c);
        }
        f.setEtat(ConstanteEtat.getEtatValider());
        f.updateToTableWithHisto(u, c);

        camp.setEtat(ConstanteEtat.getEtatCloture());
        camp.updateToTableWithHisto(u, c);
        return f;
    }
}
