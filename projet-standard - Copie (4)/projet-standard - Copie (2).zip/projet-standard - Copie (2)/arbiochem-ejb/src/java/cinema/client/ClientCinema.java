/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.client;

import client.Client;
import java.sql.Connection;

/**
 * Client du cinema = table CLIENT du poulet (reutilisee) + colonnes prenom / idcategorieclient.
 * La creation passe par client.Client.createObject (compte comptable, code client).
 */
public class ClientCinema extends Client {

    private String prenom;
    private String idcategorieclient;

    public ClientCinema() {
        this.setNomTable("CLIENT");
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getNom() == null || this.getNom().trim().isEmpty()) {
            throw new Exception("Le nom du client est obligatoire");
        }
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getIdcategorieclient() {
        return idcategorieclient;
    }

    public void setIdcategorieclient(String idcategorieclient) {
        this.idcategorieclient = idcategorieclient;
    }

}
