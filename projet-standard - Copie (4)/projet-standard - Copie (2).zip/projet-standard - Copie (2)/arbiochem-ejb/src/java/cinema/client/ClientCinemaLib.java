/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.client;

import java.sql.Connection;

/**
 * Lecture seule (vue CIN_CLIENT_LIB). Ne jamais ecrire avec cette classe.
 */
public class ClientCinemaLib extends ClientCinema {

    private String idcategorieclientlib;
    private String nomcomplet;

    public ClientCinemaLib() {
        this.setNomTable("CIN_CLIENT_LIB");
    }

    public String getIdcategorieclientlib() {
        return idcategorieclientlib;
    }

    public void setIdcategorieclientlib(String idcategorieclientlib) {
        this.idcategorieclientlib = idcategorieclientlib;
    }

    public String getNomcomplet() {
        return nomcomplet;
    }

    public void setNomcomplet(String nomcomplet) {
        this.nomcomplet = nomcomplet;
    }

}
