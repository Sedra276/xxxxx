/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.salle;

import java.sql.Connection;

/**
 * Lecture seule (vue PLACE_LIB).
 */
public class PlaceLib extends Place {

    private String idsallelib;
    private String idtypeplacelib;

    public PlaceLib() {
        this.setNomTable("PLACE_LIB");
    }

    public String getIdsallelib() {
        return idsallelib;
    }

    public void setIdsallelib(String idsallelib) {
        this.idsallelib = idsallelib;
    }

    public String getIdtypeplacelib() {
        return idtypeplacelib;
    }

    public void setIdtypeplacelib(String idtypeplacelib) {
        this.idtypeplacelib = idtypeplacelib;
    }

}
