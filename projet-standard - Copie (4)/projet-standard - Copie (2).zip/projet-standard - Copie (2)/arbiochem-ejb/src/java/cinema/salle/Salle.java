/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.salle;

import bean.CGenUtil;
import bean.ClassMAPTable;
import cinema.utils.UtilCinema;
import java.sql.Connection;

/**
 * Salle de projection.
 */
public class Salle extends ClassMAPTable {

    private String id;
    private String nom;
    private int capacite;

    public Salle() {
        this.setNomTable("SALLE");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("SAL", "GETSEQSALLE");
        this.setId(makePK(c));
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getNom() == null || this.getNom().trim().isEmpty()) {
            throw new Exception("Le nom de la salle est obligatoire");
        }
        if (this.getCapacite() <= 0) {
            throw new Exception("La capacite doit etre superieure a 0");
        }
        // A la creation, le formulaire envoie id = "" (champ cache) : pas encore de places a compter
        if (!UtilCinema.estVide(this.getId()) && this.nombrePlaces(c) > this.getCapacite()) {
            throw new Exception("La capacite est inferieure au nombre de places deja creees");
        }
    }

    @Override
    public int updateObject(String u, Connection c) throws Exception {
        this.controler(c);
        return super.updateObject(u, c);
    }

    public int nombrePlaces(Connection c) throws Exception {
        if (UtilCinema.estVide(this.getId())) return 0;   // salle pas encore enregistree
        Place p = new Place();
        Object[] r = CGenUtil.rechercher(p, null, null, c, " and idsalle = '" + UtilCinema.id(this.getId()) + "'");
        return r.length;
    }

    public static Salle charger(String id, Connection c) throws Exception {
        Salle[] r = (Salle[]) CGenUtil.rechercher(new Salle(), null, null, c, " and id = '" + UtilCinema.id(id) + "'");
        if (r.length == 0) throw new Exception("Salle introuvable");
        return r[0];
    }

    /**
     * Genere les places d'une salle : pour chaque rangee (ex : A,B,C), les numeros 1..nbParRangee.
     * Les places deja existantes (meme rangee + numero) sont ignorees.
     * Refuse si le total depasse la capacite.
     * @return nombre de places creees
     */
    public int genererPlaces(String[] rangees, int nbParRangee, String idtypeplace, String u, Connection c) throws Exception {
        if (rangees == null || rangees.length == 0) throw new Exception("Indiquer au moins une rangee");
        if (nbParRangee <= 0) throw new Exception("Le nombre de places par rangee doit etre positif");
        UtilCinema.id(idtypeplace);
        int existantes = this.nombrePlaces(c);
        int creees = 0;
        for (int i = 0; i < rangees.length; i++) {
            String r = rangees[i] == null ? "" : rangees[i].trim().toUpperCase();
            if (r.isEmpty()) continue;
            if (!r.matches("^[A-Z0-9]{1,10}$")) throw new Exception("Rangee invalide : " + r);
            for (int n = 1; n <= nbParRangee; n++) {
                Object[] deja = CGenUtil.rechercher(new Place(), null, null, c,
                        " and idsalle = '" + UtilCinema.id(this.getId()) + "' and rangee = '" + r + "' and numero = " + n);
                if (deja.length > 0) continue;
                if (existantes + creees + 1 > this.getCapacite()) {
                    throw new Exception("Capacite de la salle depassee (" + this.getCapacite() + " places)");
                }
                Place p = new Place();
                p.setIdsalle(this.getId());
                p.setRangee(r);
                p.setNumero(n);
                p.setIdtypeplace(idtypeplace);
                p.createObject(u, c);
                creees++;
            }
        }
        return creees;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

}