/*
 * Module CINEMA - framework APJ (BICI)
 * Classe generee : respecter la regle de l'intersection (attribut = colonne).
 */

package cinema.salle;

import bean.CGenUtil;
import bean.ClassMAPTable;
import cinema.utils.UtilCinema;
import java.sql.Connection;

/**
 * Place physique d'une salle (rangee + numero, type de place).
 */
public class Place extends ClassMAPTable {

    private String id;
    private String idsalle;
    private String rangee;
    private int numero;
    private String idtypeplace;

    public Place() {
        this.setNomTable("PLACE");
    }

    @Override
    public String getTuppleID() {
        return this.getId();
    }

    @Override
    public String getAttributIDName() {
        return "id";
    }

    @Override
    public void construirePK(Connection c) throws Exception {
        this.preparePk("PLC", "GETSEQPLACE");
        this.setId(makePK(c));
    }

    @Override
    public void controler(Connection c) throws Exception {
        super.controler(c);
        if (this.getIdsalle() == null || this.getIdsalle().isEmpty()) throw new Exception("La salle est obligatoire");
        if (this.getRangee() == null || this.getRangee().trim().isEmpty()) throw new Exception("La rangee est obligatoire");
        if (this.getNumero() <= 0) throw new Exception("Le numero de place doit etre positif");
        if (this.getIdtypeplace() == null || this.getIdtypeplace().isEmpty()) throw new Exception("Le type de place est obligatoire");
        this.setRangee(this.getRangee().trim().toUpperCase());
        if (this.getId() == null || this.getId().isEmpty()) {
            Salle s = Salle.charger(this.getIdsalle(), c);
            if (s.nombrePlaces(c) >= s.getCapacite()) {
                throw new Exception("Capacite de la salle atteinte (" + s.getCapacite() + " places)");
            }
        }
    }

    @Override
    public int updateObject(String u, Connection c) throws Exception {
        this.controler(c);
        return super.updateObject(u, c);
    }

    public String getLibelle() {
        return (rangee == null ? "" : rangee) + numero;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdsalle() {
        return idsalle;
    }

    public void setIdsalle(String idsalle) {
        this.idsalle = idsalle;
    }

    public String getRangee() {
        return rangee;
    }

    public void setRangee(String rangee) {
        this.rangee = rangee;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getIdtypeplace() {
        return idtypeplace;
    }

    public void setIdtypeplace(String idtypeplace) {
        this.idtypeplace = idtypeplace;
    }

}
