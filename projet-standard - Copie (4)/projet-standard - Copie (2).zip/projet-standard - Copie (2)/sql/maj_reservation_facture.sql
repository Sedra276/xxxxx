-- =====================================================================
-- MAJ base pour : Reserver / Reserver et payer, client de passage,
-- listes clients / reservations / factures.
-- Lancer avec :  SQL> @/tmp/maj_reservation_facture.sql
-- Ne supprime aucune donnee.
-- =====================================================================
SET SERVEROUTPUT ON

-- 1. Client facultatif (client de passage) sur la reservation et la facture
BEGIN
  FOR t IN (SELECT table_name FROM user_tab_columns
            WHERE table_name IN ('RESERVATION', 'FACTURECLIENT') AND column_name = 'IDCLIENT' AND nullable = 'N') LOOP
    EXECUTE IMMEDIATE 'ALTER TABLE ' || t.table_name || ' MODIFY (idclient NULL)';
    DBMS_OUTPUT.PUT_LINE(t.table_name || '.IDCLIENT rendu facultatif');
  END LOOP;
END;
/

-- 2. Clients : toutes les colonnes de CLIENT (la classe Java herite de Client)
CREATE OR REPLACE VIEW cin_client_lib AS
SELECT c.*,
       cat.val                                  AS idcategorieclientlib,
       TRIM(c.nom || ' ' || NVL(c.prenom, ''))  AS nomcomplet
FROM client c
LEFT JOIN typecategorieclient cat ON cat.id = c.idcategorieclient;

-- 3. Reservations de seance : LEFT JOIN client (client de passage visible)
CREATE OR REPLACE VIEW cin_reservation_lib AS
SELECT r.*,
       NVL(TRIM(cl.nom || ' ' || NVL(cl.prenom, '')), 'Client de passage') AS idclientlib,
       sl.libelle                                                         AS idseancelib,
       sa.nom                                                             AS salle
FROM reservation r
LEFT JOIN client cl     ON cl.id = r.idclient
LEFT JOIN seance_lib sl ON sl.id = r.idseance
LEFT JOIN seance se     ON se.id = r.idseance
LEFT JOIN salle sa      ON sa.id = se.idsalle
WHERE r.idseance IS NOT NULL;

-- 4. Factures : montants, paiements, reste, statut ; LEFT JOIN client
CREATE OR REPLACE VIEW factureclient_lib AS
SELECT f.*,
       NVL(TRIM(cl.nom || ' ' || NVL(cl.prenom, '')), 'Client de passage') AS idclientlib,
       NVL(d.ht, 0)                                                       AS montantht,
       NVL(d.ttc, 0)                                                      AS montantttc,
       NVL(p.paye, 0)                                                     AS montantpaye,
       NVL(d.ttc, 0) - NVL(p.paye, 0)                                     AS resteapayer,
       CASE WHEN NVL(d.ttc, 0) > 0 AND NVL(d.ttc, 0) - NVL(p.paye, 0) <= 0 THEN 'PAYEE'
            WHEN NVL(p.paye, 0) > 0 THEN 'PARTIELLE'
            ELSE 'IMPAYEE' END                                            AS statutpaiement
FROM factureclient f
LEFT JOIN client cl ON cl.id = f.idclient
LEFT JOIN (SELECT idfactureclient,
                  SUM(qte * pu - NVL(remises, 0))                              AS ht,
                  SUM((qte * pu - NVL(remises, 0)) * (1 + NVL(tva, 0) / 100))  AS ttc
           FROM factureclientdetails GROUP BY idfactureclient) d ON d.idfactureclient = f.id
LEFT JOIN (SELECT idfactureclient, SUM(montant) AS paye
           FROM paiementfacture GROUP BY idfactureclient) p ON p.idfactureclient = f.id;

-- 5. Recompiler les vues devenues invalides (V_CIN_*, etc.)
BEGIN
  FOR v IN (SELECT object_name FROM user_objects WHERE object_type = 'VIEW' AND status <> 'VALID'
            AND (object_name LIKE 'CIN%' OR object_name LIKE 'V_CIN%' OR object_name LIKE 'FACTURECLIENT%'
                 OR object_name LIKE 'PAIEMENTFACTURE%' OR object_name LIKE 'DETAILSRESERVATION%' OR object_name LIKE 'TICKET%')) LOOP
    BEGIN
      EXECUTE IMMEDIATE 'ALTER VIEW ' || v.object_name || ' COMPILE';
    EXCEPTION WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('A verifier : ' || v.object_name || ' -> ' || SQLERRM);
    END;
  END LOOP;
END;
/

-- =====================================================================
-- CONTROLES
-- =====================================================================
-- a) vues du module : toutes VALID
SELECT object_name, status FROM user_objects
WHERE object_type = 'VIEW' AND object_name IN
      ('CIN_CLIENT_LIB', 'CIN_RESERVATION_LIB', 'FACTURECLIENT_LIB', 'V_CIN_ETAT_PAIEMENT', 'V_CIN_KPI', 'PAIEMENTFACTURE_LIB')
ORDER BY object_name;

-- b) colonnes de CLIENT absentes de CIN_CLIENT_LIB : aucune ligne
SELECT column_name FROM user_tab_columns WHERE table_name = 'CLIENT'
MINUS
SELECT column_name FROM user_tab_columns WHERE table_name = 'CIN_CLIENT_LIB';

-- c) les 3 listes se lisent
SELECT COUNT(*) nb_clients      FROM cin_client_lib;
SELECT COUNT(*) nb_reservations FROM cin_reservation_lib;
SELECT COUNT(*) nb_factures     FROM factureclient_lib;














mardi 17 novembre : le petit LUMURIEN 14h A1,A2
VENDREDI 20 NOVEMBRE :NUIT SUR ANALAMANGA C1 D1
